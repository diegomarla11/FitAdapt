import type {
  PuntoPose,
  EstadoValidacionTecnica,
} from "@/tipos/validacionTecnica";
import {
  calcularAngulo,
  obtenerPuntosPrincipales,
} from "@/lib/validacion/calcularAngulos";

type ResultadoFrame = {
  anguloCodo: number | null;
  alineacionTronco: number | null;
};

function analizarFrameFlexiones(puntos: PuntoPose[]): ResultadoFrame | null {
  const {
    hombroIzquierdo,
    codoIzquierdo,
    muñecaIzquierda,
    caderaIzquierda,
    tobilloIzquierdo,
  } = obtenerPuntosPrincipales(puntos);

  if (
    !hombroIzquierdo ||
    !codoIzquierdo ||
    !muñecaIzquierda ||
    !caderaIzquierda ||
    !tobilloIzquierdo
  ) {
    return null;
  }

  const anguloCodo = calcularAngulo(
    hombroIzquierdo,
    codoIzquierdo,
    muñecaIzquierda,
  );

  const alineacionTronco = calcularAngulo(
    hombroIzquierdo,
    caderaIzquierda,
    tobilloIzquierdo,
  );

  return {
    anguloCodo,
    alineacionTronco,
  };
}

export function evaluarFlexiones(frames: PuntoPose[][]) {
  const framesValidos = frames
    .map((frame) => analizarFrameFlexiones(frame))
    .filter((frame): frame is ResultadoFrame => Boolean(frame));

  if (framesValidos.length < 5) {
    return {
      puntuacion: 0,
      estado: "no_evaluable" as const,
      mensajes: [
        "No se han detectado suficientes puntos corporales para evaluar las flexiones.",
        "Prueba con un vídeo de lado, cuerpo completo visible y cámara estable.",
      ],
    };
  }

  const angulosCodo = framesValidos
    .map((frame) => frame.anguloCodo)
    .filter((valor): valor is number => valor !== null);

  const alineacionesTronco = framesValidos
    .map((frame) => frame.alineacionTronco)
    .filter((valor): valor is number => valor !== null);

  const anguloCodoMinimo = Math.min(...angulosCodo);
  const alineacionMedia =
    alineacionesTronco.reduce((total, valor) => total + valor, 0) /
    alineacionesTronco.length;

  const mensajes: string[] = [];
  let puntuacion = 100;

  if (anguloCodoMinimo > 110) {
    puntuacion -= 30;
    mensajes.push(
      "El rango de movimiento parece insuficiente. Intenta bajar más el pecho si puedes mantener la técnica.",
    );
  } else {
    mensajes.push("El rango de flexión de los codos parece adecuado.");
  }

  if (alineacionMedia < 150) {
    puntuacion -= 25;
    mensajes.push(
      "Se detecta pérdida de alineación corporal. Mantén hombros, cadera y tobillos más alineados.",
    );
  } else {
    mensajes.push("La alineación general del cuerpo parece estable.");
  }

  if (framesValidos.length < 10) {
    puntuacion -= 10;
    mensajes.push(
      "El vídeo tiene pocos frames evaluables. El resultado debe interpretarse como orientación.",
    );
  }

  const puntuacionFinal = Math.max(0, Math.min(100, puntuacion));

  const estado: EstadoValidacionTecnica =
    puntuacionFinal >= 85
      ? "correcto"
      : puntuacionFinal >= 65
        ? "aceptable"
        : "mejorable";

  return {
    puntuacion: puntuacionFinal,
    estado,
    mensajes,
  };
}
