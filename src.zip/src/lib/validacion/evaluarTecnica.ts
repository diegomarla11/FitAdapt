import type {
  EjercicioValidable,
  ResultadoValidacionTecnica,
  PuntoPose,
} from "@/tipos/validacionTecnica";
import { evaluarSentadilla } from "@/lib/validacion/evaluarSentadilla";
import { evaluarFlexiones } from "@/lib/validacion/evaluarFlexiones";

export function evaluarTecnica(
  ejercicio: EjercicioValidable,
  frames: PuntoPose[][]
): ResultadoValidacionTecnica {
  if (frames.length === 0) {
    return {
      ejercicio,
      puntuacion: 0,
      estado: "no_evaluable",
      mensajes: [
        "No se ha podido detectar postura en el vídeo.",
        "Prueba con buena iluminación, cámara fija y cuerpo completo visible.",
      ],
      framesAnalizados: 0,
    };
  }

  if (ejercicio === "sentadilla") {
    const resultado = evaluarSentadilla(frames);

    return {
      ejercicio,
      puntuacion: resultado.puntuacion,
      estado: resultado.estado,
      mensajes: resultado.mensajes,
      framesAnalizados: frames.length,
    };
  }

  if (ejercicio === "flexiones") {
    const resultado = evaluarFlexiones(frames);

    return {
      ejercicio,
      puntuacion: resultado.puntuacion,
      estado: resultado.estado,
      mensajes: resultado.mensajes,
      framesAnalizados: frames.length,
    };
  }

  return {
    ejercicio,
    puntuacion: 0,
    estado: "no_evaluable",
    mensajes: ["Este ejercicio todavía no tiene reglas de evaluación técnica."],
    framesAnalizados: frames.length,
  };
}