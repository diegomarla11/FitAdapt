import type {
  PuntoPose,
  EstadoValidacionTecnica,
} from "@/tipos/validacionTecnica";
import {
  calcularAngulo,
  obtenerPuntosPrincipales,
} from "@/lib/validacion/calcularAngulos";

type ResultadoFrame = {
  anguloRodilla: number | null;
  anguloCadera: number | null;
};

function analizarFrameSentadilla(puntos: PuntoPose[]): ResultadoFrame | null {
  const {
    caderaIzquierda,
    rodillaIzquierda,
    tobilloIzquierdo,
    hombroIzquierdo,
  } = obtenerPuntosPrincipales(puntos);

  if (
    !caderaIzquierda ||
    !rodillaIzquierda ||
    !tobilloIzquierdo ||
    !hombroIzquierdo
  ) {
    return null;
  }

  const anguloRodilla = calcularAngulo(
    caderaIzquierda,
    rodillaIzquierda,
    tobilloIzquierdo,
  );

  const anguloCadera = calcularAngulo(
    hombroIzquierdo,
    caderaIzquierda,
    rodillaIzquierda,
  );

  return {
    anguloRodilla,
    anguloCadera,
  };
}

export function evaluarSentadilla(frames: PuntoPose[][]) {
  const framesValidos = frames
    .map((frame) => analizarFrameSentadilla(frame))
    .filter((frame): frame is ResultadoFrame => Boolean(frame));

  if (framesValidos.length < 5) {
    return {
      puntuacion: 0,
      estado: "no_evaluable" as const,
      mensajes: [
        "No se han detectado suficientes puntos corporales para evaluar la sentadilla.",
        "Prueba con un vídeo grabado de lado, cuerpo completo visible y buena iluminación.",
      ],
    };
  }

  const angulosRodilla = framesValidos
    .map((frame) => frame.anguloRodilla)
    .filter((valor): valor is number => valor !== null);

  const angulosCadera = framesValidos
    .map((frame) => frame.anguloCadera)
    .filter((valor): valor is number => valor !== null);

  const anguloRodillaMinimo = Math.min(...angulosRodilla);
  const anguloCaderaMinimo = Math.min(...angulosCadera);

  const mensajes: string[] = [];
  let puntuacion = 100;

  if (anguloRodillaMinimo > 110) {
    puntuacion -= 30;
    mensajes.push(
      "La profundidad parece insuficiente. Intenta flexionar más la rodilla si no hay molestias.",
    );
  } else {
    mensajes.push("La profundidad general de la sentadilla parece adecuada.");
  }

  if (anguloCaderaMinimo < 45) {
    puntuacion -= 20;
    mensajes.push(
      "Se detecta una inclinación marcada del tronco. Mantén el pecho más estable y controla la bajada.",
    );
  } else {
    mensajes.push("La posición del tronco parece razonablemente estable.");
  }

  if (framesValidos.length < 10) {
    puntuacion -= 10;
    mensajes.push(
      "El vídeo contiene pocos frames evaluables. El resultado debe interpretarse con cautela.",
    );
  }

  const puntuacionFinal = Math.max(0, Math.min(100, puntuacion));

  const estado: EstadoValidacionTecnica =
    puntuacionFinal >= 85
      ? "correcto"
      : puntuacionFinal >= 65
        ? "aceptable"
        : "mejorable";

  return {
    puntuacion: puntuacionFinal,
    estado,
    mensajes,
  };
}
