"use client";

import { useEffect, useMemo, useState } from "react";
import { guardarSesionEntrenamientoAction } from "@/app/entrenamiento/acciones";
import { calcularResumenSesion } from "@/lib/dominio/progresion/calcularResumenSesion";
import { validarRepeticionesReales } from "@/lib/entrenamiento/validarRepeticionesReales";
import TarjetaSugerenciaEjercicio from "@/componentes/tarjetaSugerenciaEjercicio";
import { calcularDescansoRecomendado } from "@/lib/entrenamiento/calcularDescansoRecomendado";

import type {
  DatosReales,
  DiaEntrenamiento,
  SesionGuardada,
} from "@/tipos/entrenamiento";

type Props = {
  rutinaId: string | null;
  dias: DiaEntrenamiento[];
  sesionesGuardadas: SesionGuardada[];
};

export default function EntrenamientoActual({
  rutinaId,
  dias,
  sesionesGuardadas,
}: Props) {
  const [diaSeleccionado, setDiaSeleccionado] = useState(dias[0]?.dia ?? 1);
  const [ejerciciosCompletados, setEjerciciosCompletados] = useState<string[]>(
    []
  );
  const [datosReales, setDatosReales] = useState<DatosReales>({});
  const [guardandoSesion, setGuardandoSesion] = useState(false);
  const [mensaje, setMensaje] = useState("");
  const [notaSesion, setNotaSesion] = useState("");
  const [sesionesLocales, setSesionesLocales] =
    useState<SesionGuardada[]>(sesionesGuardadas);
  const [temporizadorEjercicioId, setTemporizadorEjercicioId] = useState<string | null>(
    null
  );
  const [segundosRestantes, setSegundosRestantes] = useState(0);
  const [temporizadorActivo, setTemporizadorActivo] = useState(false);

  const diaActual = useMemo(() => {
    return dias.find((dia) => dia.dia === diaSeleccionado);
  }, [dias, diaSeleccionado]);

  const sesionExistenteDia = useMemo(() => {
    return sesionesLocales.find((sesion) => sesion.dia === diaSeleccionado);
  }, [sesionesLocales, diaSeleccionado]);

  const resumenSesion = useMemo(() => {
    if (!diaActual) {
      return null;
    }

    const ejerciciosSeleccionados = diaActual.ejercicios
      .filter((ejercicio) => ejerciciosCompletados.includes(ejercicio.id))
      .map((ejercicio) => {
        const datosEjercicio = datosReales[ejercicio.id];

        const sensacion =
          datosEjercicio?.sensacion === "facil" ||
            datosEjercicio?.sensacion === "bien" ||
            datosEjercicio?.sensacion === "dificil"
            ? datosEjercicio.sensacion
            : "bien";

        return {
          seriesReales:
            datosEjercicio?.seriesReales?.trim() !== ""
              ? Number(datosEjercicio.seriesReales)
              : ejercicio.series,
          pesoUsado:
            datosEjercicio?.pesoUsado?.trim() !== ""
              ? Number(datosEjercicio.pesoUsado)
              : null,
          sensacion,
        };
      });

    return calcularResumenSesion(ejerciciosSeleccionados);
  }, [diaActual, ejerciciosCompletados, datosReales]);

  // Este efecto sincroniza el estado editable de la pantalla cuando cambia
  // el día seleccionado o cuando existe una sesión guardada para ese día.
  const estadoSesionActual = useMemo(() => {
    if (!diaActual || !sesionExistenteDia) {
      return {
        ejerciciosCompletadosIniciales: [] as string[],
        datosRealesIniciales: {} as DatosReales,
        notaSesionInicial: "",
      };
    }

    const ejerciciosCompletadosIniciales = diaActual.ejercicios
      .filter((ejercicioPantalla) =>
        sesionExistenteDia.sesion_ejercicios.some((ejercicioSesion) => {
          if (!ejercicioSesion.completado) {
            return false;
          }

          if (ejercicioSesion.ejercicio_id) {
            return ejercicioSesion.ejercicio_id === ejercicioPantalla.id;
          }

          return ejercicioSesion.nombre_ejercicio === ejercicioPantalla.nombre;
        })
      )
      .map((ejercicio) => ejercicio.id);

    const datosRealesIniciales: DatosReales = {};

    for (const ejercicioSesion of sesionExistenteDia.sesion_ejercicios) {
      const ejercicioPantalla = diaActual.ejercicios.find((ejercicio) => {
        if (ejercicioSesion.ejercicio_id) {
          return ejercicio.id === ejercicioSesion.ejercicio_id;
        }

        return ejercicio.nombre === ejercicioSesion.nombre_ejercicio;
      });

      if (ejercicioPantalla) {
        datosRealesIniciales[ejercicioPantalla.id] = {
          estado: ejercicioSesion.estado_resultado ?? "completado",
          seriesReales: ejercicioSesion.series_reales?.toString() ?? "",
          repeticionesReales: ejercicioSesion.repeticiones_reales ?? "",
          pesoUsado: ejercicioSesion.peso_usado?.toString() ?? "",
          sensacion: ejercicioSesion.sensacion ?? "",
          nivelDolor: ejercicioSesion.nivel_dolor?.toString() ?? "",
          fatiga: ejercicioSesion.fatiga?.toString() ?? "",
          descansoRecomendado:
            ejercicioSesion.descanso_recomendado?.toString() ?? "",
          descansoReal: ejercicioSesion.descanso_real?.toString() ?? "",
          motivoParcial: ejercicioSesion.motivo_parcial ?? "",
        };
      }
    }

    return {
      ejerciciosCompletadosIniciales,
      datosRealesIniciales,
      notaSesionInicial: sesionExistenteDia.nota_sesion ?? "",
    };
  }, [diaActual, sesionExistenteDia]);

  useEffect(() => {
    queueMicrotask(() => {
      setEjerciciosCompletados(estadoSesionActual.ejerciciosCompletadosIniciales);
      setDatosReales(estadoSesionActual.datosRealesIniciales);
      setNotaSesion(estadoSesionActual.notaSesionInicial);
    });
  }, [estadoSesionActual]);

  useEffect(() => {
    if (!temporizadorActivo || segundosRestantes <= 0) {
      return;
    }

    const intervalo = window.setInterval(() => {
      setSegundosRestantes((actual) => {
        if (actual <= 1) {
          setTemporizadorActivo(false);
          return 0;
        }

        return actual - 1;
      });
    }, 1000);

    return () => {
      window.clearInterval(intervalo);
    };
  }, [temporizadorActivo, segundosRestantes]);

  function cambiarEstadoEjercicio(idEjercicio: string) {
    const yaEstaCompletado = ejerciciosCompletados.includes(idEjercicio);

    if (yaEstaCompletado) {
      setEjerciciosCompletados((actuales) =>
        actuales.filter((id) => id !== idEjercicio)
      );

      setDatosReales((actuales) => {
        const nuevosDatos = { ...actuales };
        delete nuevosDatos[idEjercicio];
        return nuevosDatos;
      });

      return;
    }

    const ejercicioActual = diaActual?.ejercicios.find(
      (ejercicio) => ejercicio.id === idEjercicio
    );

    setEjerciciosCompletados((actuales) => [...actuales, idEjercicio]);

    setDatosReales((actuales) => ({
      ...actuales,
      [idEjercicio]: {
        estado: actuales[idEjercicio]?.estado ?? "completado",
        seriesReales:
          actuales[idEjercicio]?.seriesReales ??
          (ejercicioActual?.ultimoRegistro?.series_reales !== null &&
            ejercicioActual?.ultimoRegistro?.series_reales !== undefined
            ? String(ejercicioActual.ultimoRegistro.series_reales)
            : ejercicioActual
              ? String(ejercicioActual.series)
              : ""),
        repeticionesReales: actuales[idEjercicio]?.repeticionesReales ?? "",
        pesoUsado:
          actuales[idEjercicio]?.pesoUsado ??
          (ejercicioActual?.ultimoRegistro?.peso_usado !== null &&
            ejercicioActual?.ultimoRegistro?.peso_usado !== undefined
            ? String(ejercicioActual.ultimoRegistro.peso_usado)
            : ""),
        sensacion:
          actuales[idEjercicio]?.sensacion ??
          ejercicioActual?.ultimoRegistro?.sensacion ??
          "bien",
        nivelDolor:
          actuales[idEjercicio]?.nivelDolor ??
          (ejercicioActual?.ultimoRegistro?.nivel_dolor !== null &&
            ejercicioActual?.ultimoRegistro?.nivel_dolor !== undefined
            ? String(ejercicioActual.ultimoRegistro.nivel_dolor)
            : ""),
        fatiga:
          actuales[idEjercicio]?.fatiga ??
          (ejercicioActual?.ultimoRegistro?.fatiga !== null &&
            ejercicioActual?.ultimoRegistro?.fatiga !== undefined
            ? String(ejercicioActual.ultimoRegistro.fatiga)
            : ""),
        descansoRecomendado: actuales[idEjercicio]?.descansoRecomendado ?? "",
        descansoReal: actuales[idEjercicio]?.descansoReal ?? "",
        motivoParcial: actuales[idEjercicio]?.motivoParcial ?? "",
      },
    }));
  }

  function obtenerEtiquetaEstado(estado: string | undefined) {
    if (estado === "parcial") return "Hice menos";
    if (estado === "superado") return "Hice más";
    return "Hecho";
  }

  function obtenerColorEstado(estado: string | undefined, completado: boolean) {
    if (!completado) {
      return "border-gray-200 bg-white";
    }

    if (estado === "parcial") {
      return "border-yellow-300 bg-yellow-50";
    }

    if (estado === "superado") {
      return "border-blue-300 bg-blue-50";
    }

    return "border-green-300 bg-green-50";
  }

  function obtenerColorBadgeEstado(estado: string | undefined) {
    if (estado === "parcial") {
      return "bg-yellow-100 text-yellow-900 border-yellow-300";
    }

    if (estado === "superado") {
      return "bg-blue-100 text-blue-900 border-blue-300";
    }

    return "bg-green-100 text-green-900 border-green-300";
  }

  function formatearSensacionCorta(sensacion: string | undefined) {
    if (sensacion === "facil") return "Fácil";
    if (sensacion === "dificil") return "Difícil";
    if (sensacion === "bien") return "Bien";
    return "Sin indicar";
  }

  function cambiarDatoReal(
    idEjercicio: string,
    campo:
      | "estado"
      | "seriesReales"
      | "repeticionesReales"
      | "pesoUsado"
      | "sensacion"
      | "nivelDolor"
      | "fatiga"
      | "descansoReal"
      | "motivoParcial",
    valor: string
  ) {
    setDatosReales((actuales) => ({
      ...actuales,
      [idEjercicio]: {
        estado: actuales[idEjercicio]?.estado ?? "completado",
        seriesReales: actuales[idEjercicio]?.seriesReales ?? "",
        repeticionesReales: actuales[idEjercicio]?.repeticionesReales ?? "",
        pesoUsado: actuales[idEjercicio]?.pesoUsado ?? "",
        sensacion: actuales[idEjercicio]?.sensacion ?? "",
        nivelDolor: actuales[idEjercicio]?.nivelDolor ?? "",
        fatiga: actuales[idEjercicio]?.fatiga ?? "",
        descansoRecomendado: actuales[idEjercicio]?.descansoRecomendado ?? "",
        descansoReal: actuales[idEjercicio]?.descansoReal ?? "",
        motivoParcial: actuales[idEjercicio]?.motivoParcial ?? "",
        [campo]: valor,
      },
    }));
  }

  function formatearTiempo(segundos: number) {
    const minutos = Math.floor(segundos / 60);
    const restoSegundos = segundos % 60;

    return `${minutos}:${restoSegundos.toString().padStart(2, "0")}`;
  }

  function iniciarTemporizador(idEjercicio: string, segundos: number) {
    setTemporizadorEjercicioId(idEjercicio);
    setSegundosRestantes(segundos);
    setTemporizadorActivo(true);
  }

  function pausarTemporizador() {
    setTemporizadorActivo(false);
  }

  function reanudarTemporizador() {
    if (segundosRestantes > 0) {
      setTemporizadorActivo(true);
    }
  }

  function reiniciarTemporizador(idEjercicio: string, segundos: number) {
    setTemporizadorEjercicioId(idEjercicio);
    setSegundosRestantes(segundos);
    setTemporizadorActivo(true);
  }

  function finalizarTemporizador() {
    setTemporizadorActivo(false);
    setSegundosRestantes(0);
    setTemporizadorEjercicioId(null);
  }

  async function guardarSesion() {
    if (!diaActual) {
      return;
    }

    try {
      setGuardandoSesion(true);
      setMensaje("");

      const ejerciciosSeleccionados = diaActual.ejercicios
        .filter((ejercicio) => ejerciciosCompletados.includes(ejercicio.id))
        .map((ejercicio) => {
          const datosEjercicio = datosReales[ejercicio.id];

          const seriesPlanificadas = ejercicio.series;
          const repeticionesPlanificadas = ejercicio.repeticiones;

          const seriesReales =
            datosEjercicio?.seriesReales?.trim() !== ""
              ? Number(datosEjercicio.seriesReales)
              : seriesPlanificadas;

          const repeticionesReales =
            datosEjercicio?.repeticionesReales?.trim() !== ""
              ? datosEjercicio.repeticionesReales.trim()
              : "";

          const pesoUsado =
            datosEjercicio?.pesoUsado?.trim() !== ""
              ? Number(datosEjercicio.pesoUsado)
              : null;

          const sensacion =
            datosEjercicio?.sensacion === "facil" ||
              datosEjercicio?.sensacion === "bien" ||
              datosEjercicio?.sensacion === "dificil"
              ? datosEjercicio.sensacion
              : "bien";

          const estado = datosEjercicio?.estado ?? "completado";

          const nivelDolor =
            datosEjercicio?.nivelDolor?.trim() !== ""
              ? Number(datosEjercicio.nivelDolor)
              : 0;

          const fatiga =
            datosEjercicio?.fatiga?.trim() !== ""
              ? Number(datosEjercicio.fatiga)
              : 5;

          const descansoRecomendado = calcularDescansoRecomendado({
            grupoMuscular: ejercicio.grupo_muscular,
            series: seriesPlanificadas,
            repeticiones: repeticionesPlanificadas,
          });

          const descansoReal =
            datosEjercicio?.descansoReal?.trim() !== ""
              ? Number(datosEjercicio.descansoReal)
              : descansoRecomendado;

          const motivoParcial =
            datosEjercicio?.motivoParcial?.trim() !== ""
              ? datosEjercicio.motivoParcial.trim()
              : null;

          return {
            ejercicioId: ejercicio.id,
            nombre: ejercicio.nombre,
            grupo_muscular: ejercicio.grupo_muscular,
            series: seriesPlanificadas,
            repeticiones: repeticionesPlanificadas,
            estado,
            seriesReales,
            repeticionesReales,
            pesoUsado,
            sensacion,
            nivelDolor,
            fatiga,
            descansoRecomendado,
            descansoReal,
            motivoParcial,
          };
        });

      const ejercicioInvalido = ejerciciosSeleccionados.find((ejercicio) => {
        const repeticionesParaValidar =
          ejercicio.repeticionesReales.trim() === ejercicio.repeticiones.trim()
            ? ""
            : ejercicio.repeticionesReales;

        return !validarRepeticionesReales(
          ejercicio.seriesReales,
          repeticionesParaValidar
        );
      });

      if (ejercicioInvalido) {
        setMensaje(
          `Revisa los datos reales de "${ejercicioInvalido.nombre}". El número de repeticiones debe coincidir con las series reales.`
        );
        setGuardandoSesion(false);
        return;
      }

      const ejercicioDolorInvalido = ejerciciosSeleccionados.find((ejercicio) => {
        return (
          ejercicio.nivelDolor !== null &&
          (!Number.isFinite(ejercicio.nivelDolor) ||
            ejercicio.nivelDolor < 0 ||
            ejercicio.nivelDolor > 10)
        );
      });

      if (ejercicioDolorInvalido) {
        setMensaje(
          `Revisa el dolor de "${ejercicioDolorInvalido.nombre}". Debe estar entre 0 y 10.`
        );
        setGuardandoSesion(false);
        return;
      }

      const ejercicioFatigaInvalida = ejerciciosSeleccionados.find((ejercicio) => {
        return (
          ejercicio.fatiga !== null &&
          (!Number.isFinite(ejercicio.fatiga) ||
            ejercicio.fatiga < 0 ||
            ejercicio.fatiga > 10)
        );
      });

      if (ejercicioFatigaInvalida) {
        setMensaje(
          `Revisa la fatiga de "${ejercicioFatigaInvalida.nombre}". Debe estar entre 0 y 10.`
        );
        setGuardandoSesion(false);
        return;
      }

      const resultadoGuardado = await guardarSesionEntrenamientoAction({
        rutinaId,
        dia: diaActual.dia,
        tituloDia: diaActual.titulo,
        ejercicios: ejerciciosSeleccionados,
        sesionIdExistente: sesionExistenteDia?.id ?? null,
        notaSesion: notaSesion.trim() || null,
      });

      const nuevaSesionLocal: SesionGuardada = {
        id: resultadoGuardado.sesion.id,
        rutina_id: resultadoGuardado.sesion.rutina_id,
        dia: resultadoGuardado.sesion.dia,
        titulo_dia: resultadoGuardado.sesion.titulo_dia,
        fecha: resultadoGuardado.sesion.fecha,
        created_at: resultadoGuardado.sesion.created_at,
        sesion_ejercicios: resultadoGuardado.ejercicios.map((ejercicio) => ({
          ...ejercicio,
          estado_resultado: ejercicio.estado_resultado ?? "completado",
        })),
        nota_sesion: resultadoGuardado.sesion.nota_sesion,
      };

      setSesionesLocales((actuales) => {
        const sinDiaActual = actuales.filter(
          (sesion) => sesion.dia !== diaActual.dia
        );

        return [nuevaSesionLocal, ...sinDiaActual];
      });

      setMensaje(
        sesionExistenteDia
          ? "Sesión actualizada correctamente. Los cambios ya se tendrán en cuenta en el progreso."
          : "Sesión guardada correctamente. El progreso ya se tendrá en cuenta para futuras adaptaciones."
      );
    } catch (error) {
      console.error("Error al guardar sesión:", error);

      const mensajeError =
        error instanceof Error
          ? error.message
          : "Ha ocurrido un error al guardar la sesión.";

      setMensaje(mensajeError);
    } finally {
      setGuardandoSesion(false);
    }
  }

  if (!diaActual) {
    return (
      <div className="rounded-2xl border p-6">
        <p className="text-gray-600">
          No hay información de entrenamiento para mostrar.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-3">
        {dias.map((dia) => (
          <button
            key={dia.dia}
            onClick={() => {
              setDiaSeleccionado(dia.dia);
              setMensaje("");
              finalizarTemporizador();
            }}
            className={`rounded-lg border px-4 py-2 ${diaSeleccionado === dia.dia
              ? "bg-black text-white"
              : "bg-white hover:bg-gray-50"
              }`}
          >
            Día {dia.dia}
          </button>
        ))}
      </div>

      <section className="rounded-2xl border p-6">
        <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div>
            <h2 className="text-2xl font-semibold">{diaActual.titulo}</h2>
            <p className="mt-1 text-sm text-gray-600">
              Marca los ejercicios realizados. Si no rellenas series o repeticiones
              reales, se guardará automáticamente lo planificado.
            </p>

            {sesionExistenteDia && (
              <p className="mt-2 text-sm font-medium text-green-700">
                Ya existe una sesión guardada para este día. Puedes revisarla y
                actualizarla.
              </p>
            )}
          </div>

          <button
            onClick={guardarSesion}
            disabled={guardandoSesion}
            className="rounded-lg bg-black px-5 py-3 text-white disabled:opacity-50"
          >
            {guardandoSesion
              ? "Guardando..."
              : sesionExistenteDia
                ? "Actualizar sesión"
                : "Guardar sesión"}
          </button>
        </div>

        {mensaje && (
          <div className="mb-5 rounded-lg border bg-gray-50 p-3 text-sm text-gray-700">
            {mensaje}
          </div>
        )}

        <details className="mb-5 rounded-xl border border-blue-200 bg-blue-50 p-3">
          <summary className="cursor-pointer list-none text-sm font-semibold text-blue-900">
            Cómo usar las sugerencias
          </summary>

          <div className="mt-3 text-sm text-blue-800">
            <p>
              Si un ejercicio tiene historial previo, la aplicación muestra los últimos
              datos registrados para ayudarte a decidir si repetir, mantener o ajustar la
              exigencia.
            </p>

            <ul className="mt-3 space-y-1">
              <li>• Si el último registro fue estable, puedes repetir una carga similar.</li>
              <li>• Si fue difícil, conviene mantener o reducir la exigencia.</li>
              <li>• Si fue fácil, puedes valorar progresar ligeramente.</li>
            </ul>
          </div>
        </details>

        <details className="mb-5 rounded-xl border bg-gray-50 p-3">
          <summary className="cursor-pointer list-none text-sm font-semibold text-gray-800">
            Añadir nota de sesión
          </summary>

          <textarea
            value={notaSesion}
            onChange={(e) => setNotaSesion(e.target.value)}
            className="mt-3 h-[70px] w-full resize-none rounded-lg border bg-white p-3 text-sm"
            placeholder="Ej. Molestia leve, subir peso la próxima vez, sesión más corta..."
          />
        </details>

        {resumenSesion && resumenSesion.ejerciciosCompletados > 0 && (
          <div className="mb-5 rounded-xl border bg-gray-50 px-4 py-3">
            <div className="flex flex-wrap items-center gap-2 text-sm text-gray-700">
              <span className="font-semibold text-gray-900">
                Resumen:
              </span>

              <span className="rounded-full border bg-white px-3 py-1">
                {resumenSesion.ejerciciosCompletados} ejercicios
              </span>

              <span className="rounded-full border bg-white px-3 py-1">
                {resumenSesion.totalSeriesReales} series
              </span>

              <span className="rounded-full border bg-white px-3 py-1">
                {resumenSesion.totalPesoRegistrado} kg registrados
              </span>

              <span className="rounded-full border bg-white px-3 py-1">
                Fácil: {resumenSesion.faciles}
              </span>

              <span className="rounded-full border bg-white px-3 py-1">
                Difícil: {resumenSesion.dificiles}
              </span>
            </div>
          </div>
        )}

        <div className="space-y-4">
          {diaActual.ejercicios.map((ejercicio) => {
            const completado = ejerciciosCompletados.includes(ejercicio.id);
            const sensacionActual = datosReales[ejercicio.id]?.sensacion ?? "";
            const descansoRecomendadoEjercicio = calcularDescansoRecomendado({
              grupoMuscular: ejercicio.grupo_muscular,
              series: ejercicio.series,
              repeticiones: ejercicio.repeticiones,
            });

            const temporizadorDeEsteEjercicio =
              temporizadorEjercicioId === ejercicio.id;
            const estadoActual = datosReales[ejercicio.id]?.estado ?? "completado";
            const colorTarjeta = obtenerColorEstado(estadoActual, completado);
            const colorBadge = obtenerColorBadgeEstado(estadoActual);

            return (
              <article
                key={ejercicio.id}
                className={`rounded-xl border p-4 transition ${colorTarjeta}`}
              >
                <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-lg font-semibold text-gray-950">
                        {ejercicio.nombre}
                      </h3>

                      {completado && (
                        <span className={`rounded-full border px-2 py-1 text-xs font-medium ${colorBadge}`}>
                          {obtenerEtiquetaEstado(estadoActual)}
                        </span>
                      )}
                    </div>

                    <p className="mt-1 text-sm text-gray-600">
                      {ejercicio.grupo_muscular} · {ejercicio.series} series ·{" "}
                      {ejercicio.repeticiones} reps · descanso {descansoRecomendadoEjercicio}s
                    </p>

                    {completado && (
                      <p className="mt-1 text-xs text-gray-600">
                        Sensación: {formatearSensacionCorta(sensacionActual)} ·{" "}
                        Dolor: {datosReales[ejercicio.id]?.nivelDolor || "0"} ·{" "}
                        Fatiga: {datosReales[ejercicio.id]?.fatiga || "5"}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {!completado ? (
                      <button
                        type="button"
                        onClick={() => cambiarEstadoEjercicio(ejercicio.id)}
                        className="rounded-lg bg-black px-4 py-2 text-sm text-white"
                      >
                        Marcar hecho
                      </button>
                    ) : (
                      <>
                        <button
                          type="button"
                          onClick={() => cambiarDatoReal(ejercicio.id, "estado", "completado")}
                          className={`rounded-lg border px-3 py-2 text-sm ${estadoActual === "completado"
                              ? "bg-black text-white"
                              : "bg-white hover:bg-gray-50"
                            }`}
                        >
                          ✓ Hecho
                        </button>

                        <button
                          type="button"
                          onClick={() => cambiarDatoReal(ejercicio.id, "estado", "parcial")}
                          className={`rounded-lg border px-3 py-2 text-sm ${estadoActual === "parcial"
                              ? "bg-yellow-200 text-yellow-950"
                              : "bg-white hover:bg-gray-50"
                            }`}
                        >
                          − Menos
                        </button>

                        <button
                          type="button"
                          onClick={() => cambiarDatoReal(ejercicio.id, "estado", "superado")}
                          className={`rounded-lg border px-3 py-2 text-sm ${estadoActual === "superado"
                              ? "bg-blue-200 text-blue-950"
                              : "bg-white hover:bg-gray-50"
                            }`}
                        >
                          + Más
                        </button>

                        <button
                          type="button"
                          onClick={() => cambiarEstadoEjercicio(ejercicio.id)}
                          className="rounded-lg border bg-white px-3 py-2 text-sm hover:bg-gray-50"
                        >
                          Desmarcar
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {ejercicio.ultimoRegistro && (
                  <details className="mt-3 rounded-lg border bg-white/70 p-3">
                    <summary className="cursor-pointer list-none text-sm font-semibold text-gray-800">
                      Ver sugerencia por historial
                    </summary>

                    <div className="mt-3">
                      <TarjetaSugerenciaEjercicio ultimoRegistro={ejercicio.ultimoRegistro} />
                    </div>
                  </details>
                )}

                {completado && (
                  <details className="mt-3 rounded-lg border bg-white p-3">
                    <summary className="cursor-pointer list-none text-sm font-semibold text-gray-800">
                      Editar datos reales y descanso
                    </summary>

                    <div className="mt-4 space-y-4">
                      <div>
                        <p className="mb-2 text-sm font-medium text-gray-700">
                          Sensación del ejercicio
                        </p>

                        <div className="flex flex-wrap gap-2">
                          {(["facil", "bien", "dificil"] as const).map((sensacion) => {
                            const activo = sensacionActual === sensacion;

                            const etiqueta =
                              sensacion === "facil"
                                ? "Fácil"
                                : sensacion === "bien"
                                  ? "Bien"
                                  : "Difícil";

                            return (
                              <button
                                key={sensacion}
                                type="button"
                                onClick={() =>
                                  cambiarDatoReal(ejercicio.id, "sensacion", sensacion)
                                }
                                className={`rounded-lg border px-4 py-2 text-sm ${activo
                                    ? "bg-black text-white"
                                    : "bg-white hover:bg-gray-50"
                                  }`}
                              >
                                {etiqueta}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
                        <div className="rounded-lg border bg-white p-3">
                          <label className="mb-1 block text-sm text-gray-600">
                            Series reales
                          </label>
                          <input
                            type="number"
                            min="0"
                            value={datosReales[ejercicio.id]?.seriesReales ?? ""}
                            onChange={(e) =>
                              cambiarDatoReal(ejercicio.id, "seriesReales", e.target.value)
                            }
                            className="w-full rounded-lg border p-2"
                            placeholder={`Planificadas: ${ejercicio.series}`}
                          />
                        </div>

                        <div className="rounded-lg border bg-white p-3">
                          <label className="mb-1 block text-sm text-gray-600">
                            Repeticiones reales
                          </label>
                          <input
                            type="text"
                            value={datosReales[ejercicio.id]?.repeticionesReales ?? ""}
                            onChange={(e) =>
                              cambiarDatoReal(
                                ejercicio.id,
                                "repeticionesReales",
                                e.target.value
                              )
                            }
                            className="w-full rounded-lg border p-2"
                            placeholder={ejercicio.repeticiones}
                          />
                        </div>

                        <div className="rounded-lg border bg-white p-3">
                          <label className="mb-1 block text-sm text-gray-600">
                            Peso usado
                          </label>
                          <input
                            type="number"
                            min="0"
                            step="0.5"
                            value={datosReales[ejercicio.id]?.pesoUsado ?? ""}
                            onChange={(e) =>
                              cambiarDatoReal(ejercicio.id, "pesoUsado", e.target.value)
                            }
                            className="w-full rounded-lg border p-2"
                            placeholder="Ej. 20 o 22.5"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
                        <div className="rounded-lg border bg-white p-3">
                          <label className="mb-1 block text-sm text-gray-600">
                            Dolor durante el ejercicio
                          </label>
                          <input
                            type="number"
                            min="0"
                            max="10"
                            value={datosReales[ejercicio.id]?.nivelDolor ?? ""}
                            onChange={(e) =>
                              cambiarDatoReal(ejercicio.id, "nivelDolor", e.target.value)
                            }
                            className="w-full rounded-lg border p-2"
                            placeholder="0 = sin dolor, 10 = máximo"
                          />
                        </div>

                        <div className="rounded-lg border bg-white p-3">
                          <label className="mb-1 block text-sm text-gray-600">
                            Fatiga percibida
                          </label>
                          <input
                            type="number"
                            min="0"
                            max="10"
                            value={datosReales[ejercicio.id]?.fatiga ?? ""}
                            onChange={(e) =>
                              cambiarDatoReal(ejercicio.id, "fatiga", e.target.value)
                            }
                            className="w-full rounded-lg border p-2"
                            placeholder="0 = sin fatiga, 10 = máxima"
                          />
                        </div>
                      </div>

                      {datosReales[ejercicio.id]?.estado === "parcial" && (
                        <div className="rounded-lg border bg-white p-3">
                          <label className="mb-1 block text-sm text-gray-600">
                            Motivo de haber hecho menos
                          </label>
                          <textarea
                            value={datosReales[ejercicio.id]?.motivoParcial ?? ""}
                            onChange={(e) =>
                              cambiarDatoReal(ejercicio.id, "motivoParcial", e.target.value)
                            }
                            className="h-[70px] w-full resize-none rounded-lg border p-2"
                            placeholder="Ej. dolor, fatiga, falta de tiempo..."
                          />
                        </div>
                      )}

                      <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
                        <div className="rounded-lg border bg-gray-50 p-3">
                          <p className="text-sm text-gray-600">Descanso recomendado</p>

                          <p className="mt-1 text-lg font-semibold">
                            {descansoRecomendadoEjercicio} segundos
                          </p>

                          <div className="mt-3 rounded-lg border bg-white p-3">
                            <p className="text-xs text-gray-500">Temporizador</p>

                            <p className="mt-1 text-2xl font-semibold">
                              {temporizadorDeEsteEjercicio
                                ? formatearTiempo(segundosRestantes)
                                : formatearTiempo(descansoRecomendadoEjercicio)}
                            </p>

                            {temporizadorDeEsteEjercicio && segundosRestantes === 0 && (
                              <p className="mt-1 text-sm font-medium text-green-700">
                                Descanso terminado.
                              </p>
                            )}

                            <div className="mt-3 flex flex-wrap gap-2">
                              <button
                                type="button"
                                onClick={() =>
                                  iniciarTemporizador(
                                    ejercicio.id,
                                    descansoRecomendadoEjercicio
                                  )
                                }
                                className="rounded-lg bg-black px-3 py-2 text-sm text-white"
                              >
                                Iniciar
                              </button>

                              {temporizadorDeEsteEjercicio && temporizadorActivo && (
                                <button
                                  type="button"
                                  onClick={pausarTemporizador}
                                  className="rounded-lg border px-3 py-2 text-sm hover:bg-gray-50"
                                >
                                  Pausar
                                </button>
                              )}

                              {temporizadorDeEsteEjercicio &&
                                !temporizadorActivo &&
                                segundosRestantes > 0 && (
                                  <button
                                    type="button"
                                    onClick={reanudarTemporizador}
                                    className="rounded-lg border px-3 py-2 text-sm hover:bg-gray-50"
                                  >
                                    Reanudar
                                  </button>
                                )}

                              <button
                                type="button"
                                onClick={() =>
                                  reiniciarTemporizador(
                                    ejercicio.id,
                                    descansoRecomendadoEjercicio
                                  )
                                }
                                className="rounded-lg border px-3 py-2 text-sm hover:bg-gray-50"
                              >
                                Reiniciar
                              </button>

                              {temporizadorDeEsteEjercicio && (
                                <button
                                  type="button"
                                  onClick={finalizarTemporizador}
                                  className="rounded-lg border px-3 py-2 text-sm hover:bg-gray-50"
                                >
                                  Cerrar
                                </button>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="rounded-lg border bg-white p-3">
                          <label className="mb-1 block text-sm text-gray-600">
                            Descanso real
                          </label>
                          <input
                            type="number"
                            min="0"
                            value={datosReales[ejercicio.id]?.descansoReal ?? ""}
                            onChange={(e) =>
                              cambiarDatoReal(ejercicio.id, "descansoReal", e.target.value)
                            }
                            className="w-full rounded-lg border p-2"
                            placeholder="Ej. 120"
                          />
                        </div>
                      </div>
                    </div>
                  </details>
                )}
              </article>
            );
          })}
        </div>
      </section>
    </div>
  );
}