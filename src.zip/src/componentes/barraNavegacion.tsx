"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import BotonCerrarSesion from "@/componentes/botonCerrarSesion";

const enlaces = [
  { href: "/inicio", label: "Inicio" },
  { href: "/perfil", label: "Perfil" },
  { href: "/rutina", label: "Rutina" },
  { href: "/entrenamiento", label: "Entrenamiento" },
  { href: "/progreso", label: "Progreso" },
  { href: "/ejercicios", label: "Ejercicios" },
  { href: "/validacion", label: "Validación" },
];

export default function BarraNavegacion() {
  const pathname = usePathname();

  const ocultarBarra = pathname === "/login";

  if (ocultarBarra) {
    return null;
  }

  return (
    <header className="sticky top-0 z-50 border-b bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-4 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-6">
          <Link href="/inicio" className="shrink-0">
            <span className="text-lg font-bold tracking-tight">TFG App</span>
          </Link>

          <nav className="flex flex-wrap items-center gap-2">
            {enlaces.map((enlace) => {
              const activo =
                pathname === enlace.href ||
                (enlace.href !== "/inicio" && pathname.startsWith(enlace.href));

              return (
                <Link
                  key={enlace.href}
                  href={enlace.href}
                  className={`rounded-full px-4 py-2 text-sm transition ${
                    activo
                      ? "bg-black text-white"
                      : "text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  {enlace.label}
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="shrink-0">
          <BotonCerrarSesion />
        </div>
      </div>
    </header>
  );
}