import type { ReactNode } from "react";

type Props = {
    titulo: string;
    descripcion?: string;
    acciones?: ReactNode;
};

export default function CabeceraPagina({
    titulo,
    descripcion,
    acciones,
}: Props) {
    return (
        <section className="rounded-2xl bg-white p-8 shadow">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div className="min-w-0">
                    <h1 className="text-3xl font-bold">{titulo}</h1>
                    {descripcion && (
                        <p className="mt-2 max-w-2xl text-gray-600">{descripcion}</p>
                    )}
                </div>

                {acciones && (
                    <div className="flex shrink-0 flex-wrap gap-3">
                        {acciones}
                    </div>
                )}
            </div>
        </section>
    );
}