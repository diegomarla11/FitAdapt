import {
  formatearSensacionEntrenamiento,
  obtenerSugerenciaEntrenamiento,
  type SensacionEntrenamiento,
} from "@/lib/entrenamiento/obtenerSugerenciaEntrenamiento";

type UltimoRegistro = {
  series_reales: number | null;
  repeticiones_reales: string | null;
  peso_usado: number | null;
  sensacion: SensacionEntrenamiento;
};

type Props = {
  ultimoRegistro: UltimoRegistro;
};

export default function TarjetaSugerenciaEjercicio({
  ultimoRegistro,
}: Props) {
  const sugerencia = obtenerSugerenciaEntrenamiento(ultimoRegistro.sensacion);

  return (
    <div className="mt-4 rounded-xl border border-blue-200 bg-blue-50 p-4">
      <div className="mb-3 space-y-2">
        <p className="text-xs font-semibold uppercase tracking-wide text-blue-700">
          Datos sugeridos desde tu último registro
        </p>

        <div>
          <p className="text-sm font-semibold text-blue-950">
            {sugerencia.titulo}
          </p>

          <p className="mt-1 text-sm text-blue-900">
            {sugerencia.descripcion}
          </p>
        </div>

        <div className="inline-flex rounded-lg border border-blue-300 bg-white px-3 py-2 text-xs font-medium text-blue-900">
          Acción recomendada: {sugerencia.accion}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-4">
        <div className="rounded-lg border border-blue-200 bg-white p-3">
          <p className="text-xs text-gray-500">Últimas series</p>
          <p className="mt-1 font-medium">
            {ultimoRegistro.series_reales ?? "-"}
          </p>
        </div>

        <div className="rounded-lg border border-blue-200 bg-white p-3">
          <p className="text-xs text-gray-500">Últimas reps</p>
          <p className="mt-1 font-medium">
            {ultimoRegistro.repeticiones_reales ?? "-"}
          </p>
        </div>

        <div className="rounded-lg border border-blue-200 bg-white p-3">
          <p className="text-xs text-gray-500">Último peso</p>
          <p className="mt-1 font-medium">
            {ultimoRegistro.peso_usado ?? "-"}
          </p>
        </div>

        <div className="rounded-lg border border-blue-200 bg-white p-3">
          <p className="text-xs text-gray-500">Sensación</p>
          <p className="mt-1 font-medium">
            {formatearSensacionEntrenamiento(ultimoRegistro.sensacion)}
          </p>
        </div>
      </div>
    </div>
  );
}