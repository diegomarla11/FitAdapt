import BarraProgreso from "@/componentes/barraProgreso";

type ResumenGlobal = {
  sesionesTotales: number;
  ejerciciosTotales: number;
  seriesTotales: number;
  pesoTotalRegistrado: number;
  sensacionesFaciles: number;
  sensacionesDificiles: number;
};

type ResumenGrupo = {
  grupo?: string;
  grupoMuscular?: string;
  apariciones: number;
  cumplimiento: number;
  ratioSeries: number;
  sensacionDominante: string;
};

type ResumenEjercicio = {
  ejercicio?: string;
  nombreEjercicio?: string;
  grupo: string;
  apariciones: number;
  cumplimiento: number;
  ratioSeries: number;
  pesoMedio: number | null;
  dolorMedio: number | null;
  fatigaMedia: number | null;
  descansoRecomendadoMedio: number | null;
  descansoRealMedio: number | null;
  ratioDescanso: number | null;
  estado: string;
};

type Props = {
  resumenGlobal: ResumenGlobal | null;
  resumenPorGrupo: ResumenGrupo[];
  resumenPorEjercicio: ResumenEjercicio[];
};

function formatearPorcentaje(valor: number) {
  return `${Math.round(valor)}%`;
}

function formatearRatio(valor: number | null) {
  if (valor === null || !Number.isFinite(valor)) {
    return "-";
  }

  return valor.toFixed(2);
}

function formatearNumero(valor: number | null, decimales = 1) {
  if (valor === null || !Number.isFinite(valor)) {
    return "-";
  }

  return valor.toFixed(decimales);
}

function formatearSegundos(valor: number | null) {
  if (valor === null || !Number.isFinite(valor)) {
    return "-";
  }

  return `${Math.round(valor)} s`;
}

function obtenerNombreEjercicio(ejercicio: ResumenEjercicio) {
  return ejercicio.ejercicio ?? ejercicio.nombreEjercicio ?? "Ejercicio";
}

export default function PanelProgresoVisual({
  resumenGlobal,
  resumenPorGrupo,
  resumenPorEjercicio,
}: Props) {
  const totalSensaciones =
    (resumenGlobal?.sensacionesFaciles ?? 0) +
    (resumenGlobal?.sensacionesDificiles ?? 0);

  const ejerciciosOrdenados = [...resumenPorEjercicio]
    .sort((a, b) => b.apariciones - a.apariciones)
    .slice(0, 8);

  const ejerciciosConDolor = [...resumenPorEjercicio]
    .filter((ejercicio) => ejercicio.dolorMedio !== null)
    .sort((a, b) => (b.dolorMedio ?? 0) - (a.dolorMedio ?? 0))
    .slice(0, 6);

  const ejerciciosConFatiga = [...resumenPorEjercicio]
    .filter((ejercicio) => ejercicio.fatigaMedia !== null)
    .sort((a, b) => (b.fatigaMedia ?? 0) - (a.fatigaMedia ?? 0))
    .slice(0, 6);

  const ejerciciosConDescanso = [...resumenPorEjercicio]
    .filter((ejercicio) => ejercicio.ratioDescanso !== null)
    .sort((a, b) => (b.ratioDescanso ?? 0) - (a.ratioDescanso ?? 0))
    .slice(0, 6);

  return (
    <section className="grid grid-cols-1 gap-6 xl:grid-cols-2">
      <div className="rounded-2xl bg-white p-6 shadow">
        <h2 className="text-xl font-semibold">Distribución de sensaciones</h2>
        <p className="mt-1 text-sm text-gray-600">
          Relación entre ejercicios registrados como fáciles o difíciles.
        </p>

        <div className="mt-5 space-y-4">
          <BarraProgreso
            etiqueta="Sensación fácil"
            valor={resumenGlobal?.sensacionesFaciles ?? 0}
            maximo={totalSensaciones || 1}
            detalle={`${resumenGlobal?.sensacionesFaciles ?? 0} registros`}
          />

          <BarraProgreso
            etiqueta="Sensación difícil"
            valor={resumenGlobal?.sensacionesDificiles ?? 0}
            maximo={totalSensaciones || 1}
            detalle={`${resumenGlobal?.sensacionesDificiles ?? 0} registros`}
          />
        </div>
      </div>

      <div className="rounded-2xl bg-white p-6 shadow">
        <h2 className="text-xl font-semibold">Cumplimiento por grupo muscular</h2>
        <p className="mt-1 text-sm text-gray-600">
          Porcentaje de ejercicios completados agrupados por zona muscular.
        </p>

        <div className="mt-5 space-y-4">
          {resumenPorGrupo.length === 0 ? (
            <p className="text-sm text-gray-600">
              Todavía no hay datos suficientes para mostrar este resumen.
            </p>
          ) : (
            resumenPorGrupo.map((grupo) => (
              <BarraProgreso
                key={grupo.grupo ?? grupo.grupoMuscular ?? "grupo"}
                etiqueta={grupo.grupo ?? grupo.grupoMuscular ?? "Grupo no indicado"}
                valor={grupo.cumplimiento}
                maximo={100}
                detalle={`${formatearPorcentaje(grupo.cumplimiento)} · ${grupo.sensacionDominante}`}
              />
            ))
          )}
        </div>
      </div>

      <div className="rounded-2xl bg-white p-6 shadow xl:col-span-2">
        <h2 className="text-xl font-semibold">Ratio de series por ejercicio</h2>
        <p className="mt-1 text-sm text-gray-600">
          Compara las series reales frente a las series planificadas. Un valor cercano a 1.00 indica que se realizó lo previsto.
        </p>

        <div className="mt-5 space-y-4">
          {ejerciciosOrdenados.length === 0 ? (
            <p className="text-sm text-gray-600">
              Todavía no hay ejercicios registrados.
            </p>
          ) : (
            ejerciciosOrdenados.map((ejercicio) => (
              <BarraProgreso
                etiqueta={obtenerNombreEjercicio(ejercicio)}
                key={`${obtenerNombreEjercicio(ejercicio)}-${ejercicio.grupo}-series`}
                valor={ejercicio.ratioSeries}
                maximo={1.5}
                detalle={`Ratio ${formatearRatio(ejercicio.ratioSeries)} · ${ejercicio.estado}`}
              />
            ))
          )}
        </div>
      </div>

      <div className="rounded-2xl bg-white p-6 shadow">
        <h2 className="text-xl font-semibold">Dolor medio por ejercicio</h2>
        <p className="mt-1 text-sm text-gray-600">
          Escala de 0 a 10. Valores altos pueden provocar cambios de variante en futuras rutinas.
        </p>

        <div className="mt-5 space-y-4">
          {ejerciciosConDolor.length === 0 ? (
            <p className="text-sm text-gray-600">
              Todavía no hay datos de dolor registrados.
            </p>
          ) : (
            ejerciciosConDolor.map((ejercicio) => (
              <BarraProgreso
                etiqueta={obtenerNombreEjercicio(ejercicio)}
                key={`${obtenerNombreEjercicio(ejercicio)}-${ejercicio.grupo}-dolor`}
                valor={ejercicio.dolorMedio ?? 0}
                maximo={10}
                detalle={`Dolor ${formatearNumero(ejercicio.dolorMedio)} · ${ejercicio.estado}`}
              />
            ))
          )}
        </div>
      </div>

      <div className="rounded-2xl bg-white p-6 shadow">
        <h2 className="text-xl font-semibold">Fatiga media por ejercicio</h2>
        <p className="mt-1 text-sm text-gray-600">
          Escala de 0 a 10. Valores altos indican acumulación de esfuerzo o recuperación insuficiente.
        </p>

        <div className="mt-5 space-y-4">
          {ejerciciosConFatiga.length === 0 ? (
            <p className="text-sm text-gray-600">
              Todavía no hay datos de fatiga registrados.
            </p>
          ) : (
            ejerciciosConFatiga.map((ejercicio) => (
              <BarraProgreso
                etiqueta={obtenerNombreEjercicio(ejercicio)}
                key={`${obtenerNombreEjercicio(ejercicio)}-${ejercicio.grupo}-fatiga`}
                valor={ejercicio.fatigaMedia ?? 0}
                maximo={10}
                detalle={`Fatiga ${formatearNumero(ejercicio.fatigaMedia)} · ${ejercicio.estado}`}
              />
            ))
          )}
        </div>
      </div>

      <div className="rounded-2xl bg-white p-6 shadow xl:col-span-2">
        <h2 className="text-xl font-semibold">Descanso real frente al recomendado</h2>
        <p className="mt-1 text-sm text-gray-600">
          Un ratio superior a 1.00 indica que el descanso real fue mayor que el recomendado.
        </p>

        <div className="mt-5 space-y-4">
          {ejerciciosConDescanso.length === 0 ? (
            <p className="text-sm text-gray-600">
              Todavía no hay datos de descanso suficientes.
            </p>
          ) : (
            ejerciciosConDescanso.map((ejercicio) => (
              <BarraProgreso
                etiqueta={obtenerNombreEjercicio(ejercicio)}
                key={`${obtenerNombreEjercicio(ejercicio)}-${ejercicio.grupo}-descanso`}
                valor={ejercicio.ratioDescanso ?? 0}
                maximo={2}
                detalle={`Ratio ${formatearRatio(ejercicio.ratioDescanso)} · recomendado ${formatearSegundos(
                  ejercicio.descansoRecomendadoMedio
                )} · real ${formatearSegundos(ejercicio.descansoRealMedio)}`}
              />
            ))
          )}
        </div>
      </div>
    </section>
  );
}