"use client";

import { useRef, useState } from "react";
import "@tensorflow/tfjs-backend-webgl";
import * as tf from "@tensorflow/tfjs";
import * as poseDetection from "@tensorflow-models/pose-detection";
import { evaluarTecnica } from "@/lib/validacion/evaluarTecnica";
import type {
  EjercicioValidable,
  PuntoPose,
  ResultadoValidacionTecnica,
} from "@/tipos/validacionTecnica";

const ejerciciosDisponibles: {
  valor: EjercicioValidable;
  etiqueta: string;
}[] = [
  { valor: "sentadilla", etiqueta: "Sentadilla" },
  { valor: "flexiones", etiqueta: "Flexiones" },
];

type DetectorPose = poseDetection.PoseDetector;

export default function ValidadorTecnica() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const detectorRef = useRef<DetectorPose | null>(null);

  const [ejercicio, setEjercicio] = useState<EjercicioValidable>("sentadilla");
  const [videoCargado, setVideoCargado] = useState(false);
  const [procesando, setProcesando] = useState(false);
  const [resultado, setResultado] =
    useState<ResultadoValidacionTecnica | null>(null);
  const [mensaje, setMensaje] = useState("");
  const [progreso, setProgreso] = useState("");

  function cargarVideo(file: File | null) {
    setMensaje("");
    setResultado(null);
    setProgreso("");

    if (!file) {
      return;
    }

    if (!file.type.startsWith("video/")) {
      setMensaje("Selecciona un archivo de vídeo válido.");
      return;
    }

    const url = URL.createObjectURL(file);

    if (videoRef.current) {
      videoRef.current.src = url;
      videoRef.current.load();
      setVideoCargado(true);
    }
  }

  async function obtenerDetector() {
    if (detectorRef.current) {
      return detectorRef.current;
    }

    setProgreso("Cargando modelo de visión artificial...");

    await tf.setBackend("webgl");
    await tf.ready();

    const detector = await poseDetection.createDetector(
      poseDetection.SupportedModels.MoveNet,
      {
        modelType: poseDetection.movenet.modelType.SINGLEPOSE_LIGHTNING,
      }
    );

    detectorRef.current = detector;

    return detector;
  }

  async function esperarCargaVideo(video: HTMLVideoElement) {
    if (video.readyState >= 2) {
      return;
    }

    await new Promise<void>((resolve) => {
      video.onloadeddata = () => resolve();
    });
  }

  async function analizarVideo() {
    const video = videoRef.current;

    if (!video) {
      setMensaje("No hay vídeo cargado.");
      return;
    }

    try {
      setProcesando(true);
      setMensaje("");
      setResultado(null);

      await esperarCargaVideo(video);

      const detector = await obtenerDetector();

      const duracion = video.duration;

      if (!Number.isFinite(duracion) || duracion <= 0) {
        setMensaje("No se ha podido leer la duración del vídeo.");
        return;
      }

      const numeroMuestras = Math.min(24, Math.max(8, Math.floor(duracion * 3)));
      const frames: PuntoPose[][] = [];

      video.pause();

      for (let indice = 0; indice < numeroMuestras; indice++) {
        const tiempo =
          numeroMuestras === 1
            ? 0
            : (duracion * indice) / (numeroMuestras - 1);

        setProgreso(`Analizando frame ${indice + 1} de ${numeroMuestras}...`);

        video.currentTime = tiempo;

        await new Promise<void>((resolve) => {
          video.onseeked = () => resolve();
        });

        const poses = await detector.estimatePoses(video);

        const primeraPose = poses[0];

        if (primeraPose?.keypoints?.length) {
          frames.push(
            primeraPose.keypoints.map((punto) => ({
              name: punto.name ?? "",
              x: punto.x,
              y: punto.y,
              score: punto.score,
            }))
          );
        }
      }

      const resultadoEvaluacion = evaluarTecnica(ejercicio, frames);

      setResultado(resultadoEvaluacion);
      setProgreso("Análisis completado.");
    } catch (error) {
      console.error("Error analizando técnica:", error);
      setMensaje(
        "No se ha podido analizar el vídeo. Prueba con un vídeo más corto, buena iluminación y cuerpo completo visible."
      );
      setProgreso("");
    } finally {
      setProcesando(false);
    }
  }

  function obtenerColorEstado(estado: ResultadoValidacionTecnica["estado"]) {
    if (estado === "correcto") {
      return "border-green-200 bg-green-50 text-green-900";
    }

    if (estado === "aceptable") {
      return "border-blue-200 bg-blue-50 text-blue-900";
    }

    if (estado === "mejorable") {
      return "border-yellow-200 bg-yellow-50 text-yellow-900";
    }

    return "border-gray-200 bg-gray-50 text-gray-800";
  }

  return (
    <section className="rounded-2xl bg-white p-6 shadow">
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[0.9fr_1.1fr]">
        <div className="space-y-5">
          <div>
            <h2 className="text-xl font-semibold">Evaluar ejercicio</h2>
            <p className="mt-1 text-sm text-gray-600">
              Sube un vídeo corto. Para esta primera versión se recomiendan vídeos
              de lado, con cuerpo completo visible y buena iluminación.
            </p>
          </div>

          <div className="rounded-xl border border-blue-200 bg-blue-50 p-4">
            <h3 className="text-sm font-semibold text-blue-900">
              Recomendaciones de grabación
            </h3>
            <ul className="mt-2 space-y-1 text-sm text-blue-800">
              <li>• Cámara fija, sin movimientos bruscos.</li>
              <li>• Vídeo de 3 a 8 segundos.</li>
              <li>• Cuerpo completo visible durante todo el ejercicio.</li>
              <li>• Ropa que permita distinguir brazos, piernas y tronco.</li>
            </ul>
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium text-gray-700">
              Ejercicio
            </label>
            <select
              value={ejercicio}
              onChange={(e) => setEjercicio(e.target.value as EjercicioValidable)}
              className="w-full rounded-lg border p-3"
            >
              {ejerciciosDisponibles.map((item) => (
                <option key={item.valor} value={item.valor}>
                  {item.etiqueta}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium text-gray-700">
              Vídeo
            </label>
            <input
              type="file"
              accept="video/*"
              onChange={(e) => cargarVideo(e.target.files?.[0] ?? null)}
              className="w-full rounded-lg border bg-white p-3"
            />
          </div>

          <button
            type="button"
            onClick={analizarVideo}
            disabled={!videoCargado || procesando}
            className="w-full rounded-lg bg-black px-5 py-3 text-white disabled:opacity-50"
          >
            {procesando ? "Analizando..." : "Analizar técnica"}
          </button>

          {progreso && (
            <div className="rounded-xl border bg-gray-50 p-4 text-sm text-gray-700">
              {progreso}
            </div>
          )}

          {mensaje && (
            <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
              {mensaje}
            </div>
          )}
        </div>

        <div className="space-y-5">
          <div className="overflow-hidden rounded-2xl border bg-black">
            <video
              ref={videoRef}
              controls
              playsInline
              className="aspect-video w-full bg-black object-contain"
            />
          </div>

          {resultado && (
            <div
              className={`rounded-2xl border p-5 ${obtenerColorEstado(
                resultado.estado
              )}`}
            >
              <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div>
                  <p className="text-sm opacity-80">Resultado técnico</p>
                  <h3 className="text-xl font-semibold capitalize">
                    {resultado.estado.replaceAll("_", " ")}
                  </h3>
                </div>

                <div className="rounded-full border bg-white px-4 py-2 text-sm font-semibold text-black">
                  {resultado.puntuacion}/100
                </div>
              </div>

              <ul className="mt-4 space-y-2 text-sm">
                {resultado.mensajes.map((mensajeResultado) => (
                  <li key={mensajeResultado}>• {mensajeResultado}</li>
                ))}
              </ul>

              <p className="mt-4 text-xs opacity-80">
                Frames analizados: {resultado.framesAnalizados}
              </p>
            </div>
          )}

          <div className="rounded-xl border bg-gray-50 p-4">
            <h3 className="text-sm font-semibold text-gray-800">
              Limitaciones del análisis
            </h3>
            <p className="mt-2 text-sm text-gray-600">
              Este módulo ofrece una orientación técnica aproximada basada en puntos
              corporales detectados por visión artificial. No sustituye la valoración
              de un profesional y puede fallar si el vídeo no muestra bien el cuerpo.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}