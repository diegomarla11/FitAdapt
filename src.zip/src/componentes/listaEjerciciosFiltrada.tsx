"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import type { Ejercicio } from "@/tipos/ejercicio";
import Image from "next/image";

type Props = {
  ejercicios: Ejercicio[];
};

type OrdenEjercicios = "nombre" | "grupo" | "dificultad" | "equipamiento";

function normalizarTexto(valor: string | null | undefined) {
  return (
    valor
      ?.toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim() ?? ""
  );
}

function formatearTexto(valor: string | null | undefined) {
  if (!valor) {
    return "No indicado";
  }

  return valor
    .split(",")
    .map((parte) => parte.trim())
    .filter(Boolean)
    .map((parte) => parte.charAt(0).toUpperCase() + parte.slice(1))
    .join(", ");
}

function obtenerTextoBusquedaEjercicio(ejercicio: Ejercicio) {
  return normalizarTexto(
    [
      ejercicio.nombre,
      ejercicio.grupo_muscular,
      ejercicio.patron_movimiento,
      ejercicio.equipamiento,
      ejercicio.dificultad,
      ejercicio.descripcion,
      ejercicio.instrucciones,
      ejercicio.errores_comunes,
      ejercicio.ajustes,
      ejercicio.recomendaciones_nivel,
      ejercicio.variantes,
      ejercicio.contraindicaciones,
    ]
      .filter(Boolean)
      .join(" "),
  );
}

function ordenarEjercicios(ejercicios: Ejercicio[], orden: OrdenEjercicios) {
  return [...ejercicios].sort((a, b) => {
    if (orden === "grupo") {
      const grupoA = normalizarTexto(a.grupo_muscular);
      const grupoB = normalizarTexto(b.grupo_muscular);

      if (grupoA !== grupoB) {
        return grupoA.localeCompare(grupoB);
      }

      return normalizarTexto(a.nombre).localeCompare(normalizarTexto(b.nombre));
    }

    if (orden === "dificultad") {
      const prioridad: Record<string, number> = {
        principiante: 1,
        intermedio: 2,
        avanzado: 3,
      };

      const dificultadA = prioridad[normalizarTexto(a.dificultad)] ?? 99;
      const dificultadB = prioridad[normalizarTexto(b.dificultad)] ?? 99;

      if (dificultadA !== dificultadB) {
        return dificultadA - dificultadB;
      }

      return normalizarTexto(a.nombre).localeCompare(normalizarTexto(b.nombre));
    }

    if (orden === "equipamiento") {
      const equipamientoA = normalizarTexto(a.equipamiento);
      const equipamientoB = normalizarTexto(b.equipamiento);

      if (equipamientoA !== equipamientoB) {
        return equipamientoA.localeCompare(equipamientoB);
      }

      return normalizarTexto(a.nombre).localeCompare(normalizarTexto(b.nombre));
    }

    return normalizarTexto(a.nombre).localeCompare(normalizarTexto(b.nombre));
  });
}

export default function ListaEjerciciosFiltrada({ ejercicios }: Props) {
  const [busqueda, setBusqueda] = useState("");
  const [grupoMuscular, setGrupoMuscular] = useState("");
  const [patronMovimiento, setPatronMovimiento] = useState("");
  const [equipamiento, setEquipamiento] = useState("");
  const [dificultad, setDificultad] = useState("");
  const [orden, setOrden] = useState<OrdenEjercicios>("nombre");

  const gruposMusculares = useMemo(
    () =>
      Array.from(
        new Set(
          ejercicios
            .map((item) => item.grupo_muscular)
            .filter((valor): valor is string => Boolean(valor)),
        ),
      ).sort(),
    [ejercicios],
  );

  const patronesMovimiento = useMemo(
    () =>
      Array.from(
        new Set(
          ejercicios
            .map((item) => item.patron_movimiento)
            .filter((valor): valor is string => Boolean(valor)),
        ),
      ).sort(),
    [ejercicios],
  );

  const equipamientos = useMemo(
    () =>
      Array.from(
        new Set(
          ejercicios
            .map((item) => item.equipamiento)
            .filter((valor): valor is string => Boolean(valor)),
        ),
      ).sort(),
    [ejercicios],
  );

  const dificultades = useMemo(
    () =>
      Array.from(
        new Set(
          ejercicios
            .map((item) => item.dificultad)
            .filter((valor): valor is string => Boolean(valor)),
        ),
      ).sort(),
    [ejercicios],
  );

  const resumenPorGrupo = useMemo(() => {
    return gruposMusculares.map((grupo) => ({
      grupo,
      total: ejercicios.filter(
        (ejercicio) => ejercicio.grupo_muscular === grupo,
      ).length,
    }));
  }, [ejercicios, gruposMusculares]);

  const ejerciciosFiltrados = useMemo(() => {
    const textoBusqueda = normalizarTexto(busqueda);

    const filtrados = ejercicios.filter((ejercicio) => {
      const cumpleBusqueda =
        !textoBusqueda ||
        obtenerTextoBusquedaEjercicio(ejercicio).includes(textoBusqueda);

      const cumpleGrupo =
        !grupoMuscular || ejercicio.grupo_muscular === grupoMuscular;

      const cumplePatron =
        !patronMovimiento || ejercicio.patron_movimiento === patronMovimiento;

      const cumpleEquipamiento =
        !equipamiento || ejercicio.equipamiento === equipamiento;

      const cumpleDificultad =
        !dificultad || ejercicio.dificultad === dificultad;

      return (
        cumpleBusqueda &&
        cumpleGrupo &&
        cumplePatron &&
        cumpleEquipamiento &&
        cumpleDificultad
      );
    });

    return ordenarEjercicios(filtrados, orden);
  }, [
    busqueda,
    dificultad,
    ejercicios,
    equipamiento,
    grupoMuscular,
    orden,
    patronMovimiento,
  ]);

  function limpiarFiltros() {
    setBusqueda("");
    setGrupoMuscular("");
    setPatronMovimiento("");
    setEquipamiento("");
    setDificultad("");
    setOrden("nombre");
  }

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border bg-gray-50 p-5">
        <div className="mb-4">
          <h2 className="text-xl font-semibold">Filtros</h2>
          <p className="mt-1 text-sm text-gray-600">
            Busca por nombre, descripción o contenido técnico. También puedes
            filtrar por grupo, patrón, equipamiento y dificultad.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-6">
          <div className="xl:col-span-2">
            <label className="mb-2 block text-sm text-gray-600">Buscar</label>
            <input
              type="text"
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
              placeholder="Ej. dominadas, lumbar, rodilla..."
              className="w-full rounded-lg border p-3"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm text-gray-600">
              Grupo muscular
            </label>
            <select
              value={grupoMuscular}
              onChange={(e) => setGrupoMuscular(e.target.value)}
              className="w-full rounded-lg border p-3"
            >
              <option value="">Todos</option>
              {gruposMusculares.map((opcion) => (
                <option key={opcion} value={opcion}>
                  {formatearTexto(opcion)}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="mb-2 block text-sm text-gray-600">Patrón</label>
            <select
              value={patronMovimiento}
              onChange={(e) => setPatronMovimiento(e.target.value)}
              className="w-full rounded-lg border p-3"
            >
              <option value="">Todos</option>
              {patronesMovimiento.map((opcion) => (
                <option key={opcion} value={opcion}>
                  {formatearTexto(opcion)}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="mb-2 block text-sm text-gray-600">
              Equipamiento
            </label>
            <select
              value={equipamiento}
              onChange={(e) => setEquipamiento(e.target.value)}
              className="w-full rounded-lg border p-3"
            >
              <option value="">Todos</option>
              {equipamientos.map((opcion) => (
                <option key={opcion} value={opcion}>
                  {formatearTexto(opcion)}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="mb-2 block text-sm text-gray-600">
              Dificultad
            </label>
            <select
              value={dificultad}
              onChange={(e) => setDificultad(e.target.value)}
              className="w-full rounded-lg border p-3"
            >
              <option value="">Todas</option>
              {dificultades.map((opcion) => (
                <option key={opcion} value={opcion}>
                  {formatearTexto(opcion)}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="mb-2 block text-sm text-gray-600">
              Ordenar por
            </label>
            <select
              value={orden}
              onChange={(e) => setOrden(e.target.value as OrdenEjercicios)}
              className="w-full rounded-lg border p-3"
            >
              <option value="nombre">Nombre</option>
              <option value="grupo">Grupo muscular</option>
              <option value="dificultad">Dificultad</option>
              <option value="equipamiento">Equipamiento</option>
            </select>
          </div>
        </div>

        <div className="mt-5 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={limpiarFiltros}
            className="rounded-lg border bg-white px-4 py-2 text-sm hover:bg-gray-50"
          >
            Limpiar filtros
          </button>

          <div className="rounded-lg border bg-white px-4 py-2 text-sm text-gray-600">
            {ejerciciosFiltrados.length} de {ejercicios.length} ejercicios
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          {resumenPorGrupo.map((item) => (
            <button
              key={item.grupo}
              type="button"
              onClick={() => setGrupoMuscular(item.grupo)}
              className={`rounded-full border px-3 py-1 text-xs ${
                grupoMuscular === item.grupo
                  ? "bg-black text-white"
                  : "bg-white text-gray-700 hover:bg-gray-50"
              }`}
            >
              {formatearTexto(item.grupo)}: {item.total}
            </button>
          ))}
        </div>
      </section>

      {ejerciciosFiltrados.length === 0 ? (
        <section className="rounded-2xl border bg-white p-8 text-center">
          <h3 className="text-lg font-semibold">
            No hay ejercicios con esos filtros
          </h3>
          <p className="mt-2 text-gray-600">
            Prueba a limpiar los filtros, cambiar el equipamiento o usar una
            búsqueda más general.
          </p>

          <button
            type="button"
            onClick={limpiarFiltros}
            className="mt-4 rounded-lg bg-black px-5 py-3 text-sm text-white"
          >
            Limpiar filtros
          </button>
        </section>
      ) : (
        <section className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {ejerciciosFiltrados.map((ejercicio) => (
            <article
              key={ejercicio.id}
              className="rounded-xl border bg-white p-5 transition hover:shadow-sm"
            >
              {ejercicio.imagen_url && (
                <div className="relative mb-4 h-40 w-full overflow-hidden rounded-lg border bg-gray-100">
                  <Image
                    src={ejercicio.imagen_url}
                    alt={`Demostración del ejercicio ${ejercicio.nombre}`}
                    fill
                    sizes="(max-width: 768px) 100vw, (max-width: 1280px) 50vw, 33vw"
                    className="object-cover"
                  />
                </div>
              )}
              <div className="mb-4">
                <Link href={`/ejercicios/${ejercicio.id}`}>
                  <h2 className="text-lg font-semibold hover:underline">
                    {ejercicio.nombre}
                  </h2>
                </Link>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-lg border p-3">
                  <p className="text-xs text-gray-500">Grupo</p>
                  <p className="mt-1 text-sm font-medium">
                    {formatearTexto(ejercicio.grupo_muscular)}
                  </p>
                </div>

                <div className="rounded-lg border p-3">
                  <p className="text-xs text-gray-500">Patrón</p>
                  <p className="mt-1 text-sm font-medium">
                    {formatearTexto(ejercicio.patron_movimiento)}
                  </p>
                </div>

                <div className="rounded-lg border p-3">
                  <p className="text-xs text-gray-500">Equipamiento</p>
                  <p className="mt-1 text-sm font-medium">
                    {formatearTexto(ejercicio.equipamiento)}
                  </p>
                </div>

                <div className="rounded-lg border p-3">
                  <p className="text-xs text-gray-500">Dificultad</p>
                  <p className="mt-1 text-sm font-medium">
                    {formatearTexto(ejercicio.dificultad)}
                  </p>
                </div>
              </div>

              <div className="mt-4 rounded-lg border bg-gray-50 p-3">
                <p className="line-clamp-3 text-sm text-gray-700">
                  {ejercicio.descripcion || "Sin descripción"}
                </p>
              </div>

              <div className="mt-4">
                <Link
                  href={`/ejercicios/${ejercicio.id}`}
                  className="inline-block rounded-lg border px-4 py-2 text-sm hover:bg-gray-50"
                >
                  Ver detalle
                </Link>
              </div>
            </article>
          ))}
        </section>
      )}
    </div>
  );
}
