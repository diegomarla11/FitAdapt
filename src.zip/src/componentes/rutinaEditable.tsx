"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { guardarRutinaEditada } from "@/app/rutina/acciones";
import type { Ejercicio } from "@/tipos/ejercicio";
import type { RutinaGenerada, EjercicioRutina } from "@/tipos/rutina";
import { obtenerSustituciones } from "@/lib/rutina/obtenerSustituciones";
import Link from "next/link";
import { interpretarSolicitudRutina } from "@/lib/rutina/nlp/interpretarSolicitudRutina";
import { aplicarSolicitudRutina } from "@/lib/rutina/nlp/aplicarSolicitudRutina";

type Props = {
  rutinaInicial: RutinaGenerada;
  ejerciciosDisponibles: Ejercicio[];
  equipamientoDisponiblePerfil?: string | null;
  molestiasPerfil?: string | null;
  rutinaIdExistente?: string | null;
};

type CambioReciente = {
  id: string;
  solicitud: string;
  cambios: string[];
};

export default function RutinaEditable({
  rutinaInicial,
  ejerciciosDisponibles,
  equipamientoDisponiblePerfil,
  molestiasPerfil,
  rutinaIdExistente,
}: Props) {
  const [rutina, setRutina] = useState(rutinaInicial);
  const [indiceAbierto, setIndiceAbierto] = useState<string | null>(null);
  const [guardandoRutina, setGuardandoRutina] = useState(false);
  const [mensajeGuardado, setMensajeGuardado] = useState("");
  const [rutinaGuardada, setRutinaGuardada] = useState(Boolean(rutinaIdExistente));
  const [rutinaIdActual, setRutinaIdActual] = useState<string | null>(
    rutinaIdExistente ?? null
  );
  const [hayCambiosSinGuardar, setHayCambiosSinGuardar] = useState(false);

  const [textoSolicitud, setTextoSolicitud] = useState("");
  const [mensajeSolicitud, setMensajeSolicitud] = useState("");
  const [cambiosSolicitud, setCambiosSolicitud] = useState<string[]>([]);

  const [historialRutinas, setHistorialRutinas] = useState<RutinaGenerada[]>([]);
  const [cambiosRecientes, setCambiosRecientes] = useState<CambioReciente[]>([]);

  const router = useRouter();

  function sustituirEjercicio(
    indiceDia: number,
    indiceEjercicio: number,
    ejercicioNuevo: EjercicioRutina
  ) {

    setHistorialRutinas((actual) => [...actual, rutina]);

    const ejercicioAnterior =
      rutina.dias[indiceDia]?.ejercicios[indiceEjercicio];

    if (ejercicioAnterior) {
      setCambiosRecientes((actual) =>
        [
          {
            id: crypto.randomUUID(),
            solicitud: "Sustitución manual",
            cambios: [
              `Se ha cambiado ${ejercicioAnterior.nombre} por ${ejercicioNuevo.nombre}.`,
            ],
          },
          ...actual,
        ].slice(0, 5)
      );
    }

    setRutina((actual) => {
      const nuevosDias = [...actual.dias];
      const ejerciciosDia = [...nuevosDias[indiceDia].ejercicios];

      ejerciciosDia[indiceEjercicio] = ejercicioNuevo;

      nuevosDias[indiceDia] = {
        ...nuevosDias[indiceDia],
        ejercicios: ejerciciosDia,
      };

      return {
        ...actual,
        dias: nuevosDias,
      };
    });

    setHayCambiosSinGuardar(true);
    setRutinaGuardada(false);
    setMensajeGuardado("Tienes cambios sin guardar en la rutina.");
    setIndiceAbierto(null);
  }

  async function guardarRutina() {
    try {
      setGuardandoRutina(true);
      setMensajeGuardado("");

      const resultado = await guardarRutinaEditada(
        rutina,
        rutinaIdActual
      );

      if (!resultado.ok) {
        setMensajeGuardado(
          resultado.error ?? "No se ha podido guardar la rutina."
        );
        return;
      }

      setRutinaGuardada(true);
      setHayCambiosSinGuardar(false);
      setRutinaIdActual(resultado.rutinaId ?? rutinaIdActual);
      setMensajeGuardado(
        "Rutina guardada correctamente. Ya puedes empezar o continuar el entrenamiento."
      );
      setHistorialRutinas([]);
      setCambiosRecientes([]);
      setCambiosSolicitud([]);
      setMensajeSolicitud("");
      router.refresh();
    } catch {
      setMensajeGuardado("Ha ocurrido un error al guardar la rutina.");
    } finally {
      setGuardandoRutina(false);
    }
  }

  function aplicarSolicitudTexto() {
    const solicitud = interpretarSolicitudRutina(textoSolicitud);

    if (solicitud.mensajes.length > 0) {
      setMensajeSolicitud(solicitud.mensajes.join(" "));
      setCambiosSolicitud([]);
      return;
    }

    const resultado = aplicarSolicitudRutina(
      rutina,
      solicitud,
      ejerciciosDisponibles,
      {
        equipamientoDisponiblePerfil,
        molestiasPerfil,
      }
    );

    setHistorialRutinas((actual) => [...actual, rutina]);

    setCambiosRecientes((actual) =>
      [
        {
          id: crypto.randomUUID(),
          solicitud: textoSolicitud.trim(),
          cambios: resultado.cambios,
        },
        ...actual,
      ].slice(0, 5)
    );

    setRutina(resultado.rutina);
    setCambiosSolicitud(resultado.cambios);
    setMensajeSolicitud(
      "Solicitud aplicada a la rutina. Revisa los cambios antes de guardar."
    );
    setHayCambiosSinGuardar(true);
    setRutinaGuardada(false);
    setMensajeGuardado("Tienes cambios sin guardar en la rutina.");
  }


  return (
    <div className="space-y-8">

      <section className="rounded-2xl border bg-white p-5 shadow">
        <div className="space-y-4">
          <div>
            <p className="text-sm font-medium text-gray-500">
              Modificación por lenguaje natural
            </p>

            <h2 className="mt-1 text-xl font-semibold">
              Ajustar rutina con texto
            </h2>

            <p className="mt-2 text-sm text-gray-600">
              Escribe una petición como “quiero más pierna”, “evita hombro”,
              “hazla más corta”, “usa más mancuernas” o “quiero una rutina más suave”.
            </p>

            <textarea
              value={textoSolicitud}
              onChange={(e) => setTextoSolicitud(e.target.value)}
              className="mt-3 h-[70px] w-full resize-none rounded-xl border p-3 text-sm"
              placeholder="Ej. Quiero más pierna y menos hombro."
            />

            <div className="mt-3 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={aplicarSolicitudTexto}
                className="rounded-lg bg-black px-5 py-3 text-sm text-white"
              >
                Aplicar solicitud
              </button>

              <button
                type="button"
                onClick={() => {
                  setTextoSolicitud("");
                  setMensajeSolicitud("");
                  setCambiosSolicitud([]);
                }}
                className="rounded-lg border px-5 py-3 text-sm hover:bg-gray-50"
              >
                Limpiar texto
              </button>
            </div>
          </div>

          <details className="rounded-xl border bg-gray-50 p-4">
            <summary className="cursor-pointer list-none text-sm font-semibold text-gray-800">
              Ver ejemplos admitidos
            </summary>

            <ul className="mt-3 grid gap-2 text-sm text-gray-600 md:grid-cols-2">
              <li>• Quiero más pierna y menos hombro.</li>
              <li>• Quiero más pecho y menos tríceps.</li>
              <li>• Haz la rutina más corta.</li>
              <li>• Haz el día 2 más corto.</li>
              <li>• Haz Torso A más largo.</li>
              <li>• Usa más mancuernas y evita máquinas.</li>
              <li>• Quita dominadas.</li>
              <li>• Quita flexiones pero mantén sentadilla.</li>
              <li>• Evita ejercicios de hombro.</li>
              <li>• Quiero una rutina más suave.</li>
            </ul>
          </details>
        </div>

        {mensajeSolicitud && (
          <details className="mt-4 rounded-xl border bg-gray-50 p-4" open>
            <summary className="flex cursor-pointer list-none items-center justify-between gap-3 text-sm font-semibold text-gray-800">
              <span>Cambios aplicados</span>

              {cambiosSolicitud.length > 0 && (
                <span className="text-xs font-normal text-gray-500">
                  {cambiosSolicitud.length} cambio
                  {cambiosSolicitud.length === 1 ? "" : "s"}
                </span>
              )}
            </summary>

            <p className="mt-3 text-sm text-gray-700">{mensajeSolicitud}</p>

            {cambiosSolicitud.length > 0 && (
              <ul className="mt-3 space-y-1 text-sm text-gray-700">
                {cambiosSolicitud.slice(0, 6).map((cambio) => (
                  <li key={cambio}>• {cambio}</li>
                ))}
              </ul>
            )}

            {cambiosSolicitud.length > 6 && (
              <p className="mt-2 text-xs text-gray-500">
                +{cambiosSolicitud.length - 6} cambios más.
              </p>
            )}
          </details>
        )}

        {cambiosRecientes.length > 0 && (
          <details className="mt-4 rounded-xl border bg-gray-50 p-4">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-3 text-sm font-semibold text-gray-800">
              <span>Cambios recientes</span>
              <span className="text-xs font-normal text-gray-500">
                {cambiosRecientes.length} pendiente
                {cambiosRecientes.length === 1 ? "" : "s"}
              </span>
            </summary>

            <div className="mt-4 space-y-3">
              {cambiosRecientes.slice(0, 3).map((item, indice) => (
                <div key={item.id} className="rounded-lg border bg-white p-3">
                  <div className="flex flex-col gap-1 md:flex-row md:items-start md:justify-between">
                    <div>
                      <p className="text-sm font-semibold text-gray-800">
                        {indice === 0 ? "Último cambio" : `Cambio anterior ${indice}`}
                      </p>

                      <p className="mt-1 text-sm text-gray-600">
                        {item.solicitud ? `“${item.solicitud}”` : "Solicitud sin texto"}
                      </p>
                    </div>

                    <span className="rounded-full bg-gray-100 px-2 py-1 text-xs text-gray-600">
                      {item.cambios.length} cambio{item.cambios.length === 1 ? "" : "s"}
                    </span>
                  </div>

                  <ul className="mt-3 space-y-1 text-sm text-gray-700">
                    {item.cambios.slice(0, 3).map((cambio) => (
                      <li key={cambio}>• {cambio}</li>
                    ))}
                  </ul>

                  {item.cambios.length > 3 && (
                    <p className="mt-2 text-xs text-gray-500">
                      +{item.cambios.length - 3} cambios más.
                    </p>
                  )}
                </div>
              ))}

              <div className="flex flex-wrap gap-3 border-t pt-3">
                <button
                  type="button"
                  onClick={deshacerUltimoCambio}
                  disabled={historialRutinas.length === 0}
                  className="rounded-lg border px-4 py-2 text-sm hover:bg-white disabled:opacity-50"
                >
                  Deshacer último cambio
                </button>

                <button
                  type="button"
                  onClick={() => setCambiosRecientes([])}
                  className="rounded-lg border px-4 py-2 text-sm hover:bg-white"
                >
                  Ocultar historial
                </button>
              </div>
            </div>
          </details>
        )}
      </section>
      <section className="rounded-2xl border bg-gray-50 p-4 md:p-5">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-lg font-semibold">Guardar y editar rutina</h2>
            <p className="text-sm text-gray-600">
              Revisa la propuesta, sustituye ejercicios si lo necesitas y guarda la rutina para poder usarla en entrenamiento.
            </p>
          </div>

          <button
            onClick={guardarRutina}
            disabled={guardandoRutina}
            className="rounded-lg bg-black px-5 py-3 text-white disabled:opacity-50"
          >
            {guardandoRutina
              ? "Guardando..."
              : hayCambiosSinGuardar
                ? "Guardar cambios"
                : "Guardar rutina"}
          </button>
        </div>
        {hayCambiosSinGuardar && (
          <div className="mt-4 rounded-xl border border-yellow-300 bg-yellow-50 p-4">
            <p className="text-sm font-medium text-yellow-900">
              Hay cambios sin guardar
            </p>
            <p className="mt-1 text-sm text-yellow-800">
              Has modificado la rutina. Guarda los cambios antes de ir a entrenamiento
              para que se apliquen en la sesión.
            </p>
          </div>
        )}

        {mensajeGuardado && (
          <div className="mt-4 rounded-xl border bg-white p-4">
            <p className="text-sm text-gray-700">{mensajeGuardado}</p>

            {rutinaGuardada && (
              <div className="mt-3 flex flex-wrap gap-3">
                <Link
                  href="/entrenamiento"
                  prefetch={false}
                  className="rounded-lg bg-black px-4 py-2 text-sm text-white"
                >
                  Ir a entrenamiento
                </Link>

                <Link
                  href="/inicio"
                  className="rounded-lg border px-4 py-2 text-sm hover:bg-gray-50"
                >
                  Volver al inicio
                </Link>
              </div>
            )}
          </div>
        )}
      </section>

      {rutina.dias.map((dia, indiceDia) => (
        <section key={dia.dia} className="rounded-2xl border p-5">
          <div className="mb-4">
            <h2 className="text-xl font-semibold">{dia.titulo}</h2>
            <p className="mt-1 text-sm text-gray-600">
              Revisa los ejercicios del día y sustituye solo cuando necesites una
              alternativa compatible.
            </p>
          </div>

          <div className="space-y-3">
            {dia.ejercicios.map((ejercicio, indiceEjercicio) => {
              const clave = `${indiceDia}-${indiceEjercicio}`;

              const nombresYaUsados = dia.ejercicios
                .filter((_, indice) => indice !== indiceEjercicio)
                .map((item) => item.nombre);

              const alternativas = obtenerSustituciones(ejerciciosDisponibles, {
                nombreEjercicioActual: ejercicio.nombre,
                grupoMuscular: ejercicio.grupo_muscular,
                patronMovimiento: ejercicio.patron_movimiento,
                equipoDisponiblePerfil: equipamientoDisponiblePerfil,
                molestiasPerfil,
                nombresYaUsados,
              });

              return (
                <article
                  key={clave}
                  className="rounded-xl border bg-white p-4"
                >
                  <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-col gap-2 md:flex-row md:items-start md:justify-between">
                        <div>
                          <Link href={`/ejercicios/${ejercicio.id}`}>
                            <h3 className="font-semibold hover:underline">
                              {ejercicio.nombre}
                            </h3>
                          </Link>

                          <p className="mt-1 text-sm text-gray-600">
                            {ejercicio.grupo_muscular} ·{" "}
                            {ejercicio.patron_movimiento || "Patrón no indicado"} ·{" "}
                            {ejercicio.series} series · {ejercicio.repeticiones} reps
                          </p>

                          {ejercicio.explicacion_seleccion &&
                            !ejercicio.explicacion_progresion && (
                              <p className="mt-1 text-xs text-gray-500">
                                Seleccionado por compatibilidad con el perfil.
                              </p>
                            )}
                        </div>

                        <button
                          onClick={() =>
                            setIndiceAbierto((actual) =>
                              actual === clave ? null : clave
                            )
                          }
                          className="w-fit rounded-lg border px-4 py-2 text-sm hover:bg-gray-50"
                        >
                          {indiceAbierto === clave ? "Ocultar" : "Sustituir"}
                        </button>
                      </div>

                      {ejercicio.explicacion_progresion && (
                        <details className="mt-3 rounded-lg border border-blue-200 bg-blue-50 p-3 text-sm text-blue-900">
                          <summary className="flex cursor-pointer list-none items-center justify-between gap-3">
                            <span className="font-medium">
                              {ejercicio.explicacion_progresion.motivo
                                .toLowerCase()
                                .includes("solicitud escrita")
                                ? "Ajuste por solicitud"
                                : "Ajuste por progreso"}
                            </span>

                            <span className="text-xs">
                              {ejercicio.explicacion_progresion.accion.replaceAll("_", " ")}
                              {" · "}
                              {ejercicio.explicacion_progresion.seriesOriginales} →{" "}
                              {ejercicio.explicacion_progresion.seriesFinales}
                            </span>
                          </summary>

                          <p className="mt-2 text-sm">
                            {ejercicio.explicacion_progresion.motivo}
                          </p>

                          <div className="mt-2 grid grid-cols-1 gap-2 text-xs sm:grid-cols-3">
                            <div className="rounded-md border border-blue-200 bg-white p-2">
                              <p className="text-blue-600">Acción</p>
                              <p className="font-medium">
                                {ejercicio.explicacion_progresion.accion.replaceAll("_", " ")}
                              </p>
                            </div>

                            <div className="rounded-md border border-blue-200 bg-white p-2">
                              <p className="text-blue-600">Series</p>
                              <p className="font-medium">
                                {ejercicio.explicacion_progresion.seriesOriginales} →{" "}
                                {ejercicio.explicacion_progresion.seriesFinales}
                              </p>
                            </div>

                            <div className="rounded-md border border-blue-200 bg-white p-2">
                              <p className="text-blue-600">Ejercicio</p>
                              <p className="font-medium">
                                {ejercicio.explicacion_progresion.nombreOriginal ===
                                  ejercicio.explicacion_progresion.nombreFinal
                                  ? "Se mantiene"
                                  : `${ejercicio.explicacion_progresion.nombreOriginal} → ${ejercicio.explicacion_progresion.nombreFinal}`}
                              </p>
                            </div>
                          </div>
                        </details>
                      )}
                    </div>
                  </div>

                  {indiceAbierto === clave && (
                    <div className="mt-4 rounded-xl border bg-gray-50 p-4">
                      <div className="mb-4">
                        <p className="font-medium">Alternativas compatibles</p>
                        <p className="text-sm text-gray-600">
                          Se muestran ejercicios del mismo grupo muscular y patrón
                          o, si no existen, opciones cercanas compatibles.
                        </p>
                      </div>

                      {alternativas.length === 0 ? (
                        <p className="text-sm text-gray-600">
                          No se han encontrado alternativas para este ejercicio.
                        </p>
                      ) : (
                        <div className="space-y-3">
                          {alternativas.slice(0, 5).map((alternativa) => (
                            <div
                              key={alternativa.id}
                              className="flex flex-col gap-3 rounded-lg border bg-white p-4 md:flex-row md:items-center md:justify-between"
                            >
                              <div className="space-y-1">
                                <p className="font-medium">{alternativa.nombre}</p>
                                <p className="text-sm text-gray-600">
                                  {alternativa.grupo_muscular} ·{" "}
                                  {alternativa.patron_movimiento}
                                </p>
                                <p className="text-sm text-gray-600">
                                  Equipamiento: {alternativa.equipamiento}
                                </p>
                              </div>

                              <button
                                onClick={() =>
                                  sustituirEjercicio(indiceDia, indiceEjercicio, {
                                    id: alternativa.id,
                                    nombre: alternativa.nombre,
                                    grupo_muscular: alternativa.grupo_muscular,
                                    patron_movimiento: alternativa.patron_movimiento,
                                    dificultad: alternativa.dificultad,
                                    series: ejercicio.series,
                                    repeticiones: ejercicio.repeticiones,
                                  })
                                }
                                className="rounded-lg bg-black px-4 py-2 text-white"
                              >
                                Elegir
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );

  function deshacerUltimoCambio() {
    if (historialRutinas.length === 0) {
      setMensajeSolicitud("No hay cambios recientes para deshacer.");
      return;
    }

    const ultimaRutina = historialRutinas[historialRutinas.length - 1];

    setRutina(ultimaRutina);
    setHistorialRutinas((actual) => actual.slice(0, -1));
    setCambiosRecientes((actual) => actual.slice(1));
    setCambiosSolicitud([]);
    setMensajeSolicitud("Se ha deshecho el último cambio aplicado.");
    setHayCambiosSinGuardar(true);
    setRutinaGuardada(false);
    setMensajeGuardado("Tienes cambios sin guardar en la rutina.");
  }


}