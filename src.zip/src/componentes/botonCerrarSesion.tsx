"use client";

import { cerrarSesion } from "@/app/login/acciones";

export default function BotonCerrarSesion() {
  return (
    <form action={cerrarSesion}>
      <button
        type="submit"
        className="rounded-full border px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
      >
        Cerrar sesión
      </button>
    </form>
  );
}