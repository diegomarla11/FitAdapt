"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { actualizarPerfil } from "@/app/perfil/acciones";
import type { Perfil } from "@/tipos/perfil";
import { opcionesEquipamiento } from "@/lib/shared/opcionesEquipamiento";
import Link from "next/link";

type Props = {
  perfil: Perfil;
};

export default function FormularioPerfil({ perfil }: Props) {
  const router = useRouter();

  const equipamientoInicial = perfil.equipo_disponible
    ? perfil.equipo_disponible
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean)
    : [];

  const [nombre, setNombre] = useState(perfil.nombre || "");
  const [objetivo, setObjetivo] = useState(perfil.objetivo);
  const [nivel, setNivel] = useState(perfil.nivel);
  const [diasPorSemana, setDiasPorSemana] = useState(perfil.dias_por_semana);
  const [duracionSesion, setDuracionSesion] = useState(perfil.duracion_sesion);
  const [equipamientoSeleccionado, setEquipamientoSeleccionado] =
    useState<string[]>(equipamientoInicial);
  const [molestias, setMolestias] = useState(perfil.molestias || "");
  const [guardando, setGuardando] = useState(false);
  const [mensaje, setMensaje] = useState("");

  function cambiarEquipamiento(opcion: string) {
    setEquipamientoSeleccionado((actual) => {
      if (actual.includes(opcion)) {
        return actual.filter((item) => item !== opcion);
      }

      return [...actual, opcion];
    });
  }

  async function guardarCambios() {
    if (equipamientoSeleccionado.length === 0) {
      setMensaje("Selecciona al menos un equipo disponible.");
      return;
    }

    try {
      setGuardando(true);
      setMensaje("");

      const resultado = await actualizarPerfil({
        id: perfil.id,
        nombre: nombre.trim(),
        objetivo,
        nivel,
        dias_por_semana: Number(diasPorSemana),
        duracion_sesion: Number(duracionSesion),
        equipo_disponible: equipamientoSeleccionado.join(","),
        molestias: molestias.trim(),
      });

      if (!resultado.ok) {
        setMensaje(resultado.error || "No se ha podido guardar el perfil.");
        return;
      }

      setMensaje(
        "Perfil actualizado correctamente. Si has cambiado objetivo, nivel, días, equipamiento o molestias, conviene regenerar la rutina."
      );
      router.refresh();
    } catch {
      setMensaje("Ha ocurrido un error al guardar el perfil.");
    } finally {
      setGuardando(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div>
          <label className="mb-2 block text-sm text-gray-600">Nombre</label>
          <input
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
            className="w-full rounded-xl border p-3"
          />
        </div>

        <div>
          <label className="mb-2 block text-sm text-gray-600">Objetivo</label>
          <select
            value={objetivo}
            onChange={(e) => setObjetivo(e.target.value)}
            className="w-full rounded-xl border p-3"
          >
            <option value="hipertrofia">Hipertrofia</option>
            <option value="fuerza">Fuerza</option>
            <option value="mantenimiento">Mantenimiento</option>
            <option value="recomposicion">Recomposición</option>
          </select>
        </div>

        <div>
          <label className="mb-2 block text-sm text-gray-600">Nivel</label>
          <select
            value={nivel}
            onChange={(e) => setNivel(e.target.value)}
            className="w-full rounded-xl border p-3"
          >
            <option value="principiante">Principiante</option>
            <option value="intermedio">Intermedio</option>
            <option value="avanzado">Avanzado</option>
          </select>
        </div>

        <div>
          <label className="mb-2 block text-sm text-gray-600">
            Días por semana (1 a 7)
          </label>
          <input
            type="number"
            min={1}
            max={7}
            value={diasPorSemana}
            onChange={(e) => setDiasPorSemana(Number(e.target.value))}
            className="w-full rounded-xl border p-3"
          />
        </div>

        <div>
          <label className="mb-2 block text-sm text-gray-600">
            Duración por sesión (minutos)
          </label>
          <input
            type="number"
            min={15}
            max={180}
            value={duracionSesion}
            onChange={(e) => setDuracionSesion(Number(e.target.value))}
            className="w-full rounded-xl border p-3"
          />
        </div>
      </div>

      <div className="rounded-xl border p-4">
        <p className="mb-3 text-sm text-gray-600">Equipamiento disponible</p>

        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {opcionesEquipamiento.map((opcion) => (
            <label
              key={opcion}
              className="flex items-center gap-3 rounded-lg border p-3"
            >
              <input
                type="checkbox"
                checked={equipamientoSeleccionado.includes(opcion)}
                onChange={() => cambiarEquipamiento(opcion)}
              />
              <span className="capitalize">{opcion}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <label className="mb-2 block text-sm text-gray-600">
          Molestias o lesiones
        </label>
        <textarea
          value={molestias}
          onChange={(e) => setMolestias(e.target.value)}
          className="w-full rounded-xl border p-3"
          rows={4}
          placeholder="Ej. hombro derecho, rodilla izquierda..."
        />
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <button
          onClick={guardarCambios}
          disabled={guardando}
          className="rounded-lg bg-black px-5 py-3 text-white disabled:opacity-50"
        >
          {guardando ? "Guardando..." : "Guardar cambios"}
        </button>

        <Link
          href="/rutina?modo=nueva"
          className="inline-block rounded-lg border px-5 py-3 hover:bg-gray-50"
        >
          Regenerar rutina
        </Link>
      </div>

      {mensaje && (
        <div className="rounded-lg border bg-gray-50 p-3 text-sm text-gray-700">
          {mensaje}
        </div>
      )}
    </div>
  );
}