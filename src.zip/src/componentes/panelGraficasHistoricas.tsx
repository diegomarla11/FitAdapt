"use client";

import {
    Area,
    AreaChart,
    Bar,
    BarChart,
    CartesianGrid,
    Line,
    LineChart,
    ResponsiveContainer,
    Tooltip,
    XAxis,
    YAxis,
} from "recharts";

type PuntoEvolucion = {
    fecha: string;
    sesiones: number;
    ejercicios: number;
    seriesReales: number;
    pesoRegistrado: number;
    dolorMedio: number | null;
    fatigaMedia: number | null;
    cumplimiento: number;
    faciles: number;
    bien: number;
    dificiles: number;
};

type Props = {
    evolucion: PuntoEvolucion[];
};

function formatearFecha(fecha: string) {
    const partes = fecha.split("-");

    if (partes.length !== 3) {
        return fecha;
    }

    return `${partes[2]}/${partes[1]}`;
}

function prepararDatos(evolucion: PuntoEvolucion[]) {
    return evolucion.map((punto) => ({
        ...punto,
        fechaCorta: formatearFecha(punto.fecha),
        cumplimientoPorcentaje: Math.round(punto.cumplimiento * 100),
    }));
}

export default function PanelGraficasHistoricas({ evolucion }: Props) {
    const datos = prepararDatos(evolucion);

    if (datos.length === 0) {
        return (
            <section className="rounded-2xl bg-white p-6 shadow">
                <h2 className="text-xl font-semibold">Evolución histórica</h2>
                <p className="mt-2 text-sm text-gray-600">
                    Todavía no hay suficientes sesiones para mostrar gráficas históricas.
                </p>
            </section>
        );
    }

    return (
        <section className="grid grid-cols-1 gap-6 xl:grid-cols-2">
            <article className="rounded-2xl bg-white p-6 shadow xl:col-span-2">
                <div className="mb-5">
                    <h2 className="text-xl font-semibold">Evolución de volumen</h2>
                    <p className="mt-1 text-sm text-gray-600">
                        Muestra cómo evolucionan las series reales y el peso registrado por fecha.
                    </p>
                </div>

                <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={datos}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="fechaCorta" />
                            <YAxis yAxisId="series" />
                            <YAxis yAxisId="peso" orientation="right" />
                            <Tooltip />
                            <Area
                                yAxisId="series"
                                type="monotone"
                                dataKey="seriesReales"
                                name="Series reales"
                                stroke="#111827"
                                fill="#111827"
                                fillOpacity={0.15}
                            />
                            <Area
                                yAxisId="peso"
                                type="monotone"
                                dataKey="pesoRegistrado"
                                name="Peso registrado"
                                stroke="#2563eb"
                                fill="#2563eb"
                                fillOpacity={0.12}
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </article>

            <article className="rounded-2xl bg-white p-6 shadow">
                <div className="mb-5">
                    <h2 className="text-xl font-semibold">Cumplimiento por fecha</h2>
                    <p className="mt-1 text-sm text-gray-600">
                        Porcentaje de series reales frente a las series planificadas.
                    </p>
                </div>

                <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={datos}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="fechaCorta" />
                            <YAxis domain={[0, 120]} />
                            <Tooltip />
                            <Line
                                type="monotone"
                                dataKey="cumplimientoPorcentaje"
                                name="Cumplimiento %"
                                stroke="#111827"
                                strokeWidth={2}
                                dot
                            />
                        </LineChart>
                    </ResponsiveContainer>
                </div>
            </article>

            <article className="rounded-2xl bg-white p-6 shadow">
                <div className="mb-5">
                    <h2 className="text-xl font-semibold">Dolor y fatiga</h2>
                    <p className="mt-1 text-sm text-gray-600">
                        Evolución media de dolor y fatiga registrados en cada fecha.
                    </p>
                </div>

                <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={datos}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="fechaCorta" />
                            <YAxis domain={[0, 10]} />
                            <Tooltip />
                            <Line
                                type="monotone"
                                dataKey="dolorMedio"
                                name="Dolor medio"
                                stroke="#dc2626"
                                strokeWidth={2}
                                dot
                            />
                            <Line
                                type="monotone"
                                dataKey="fatigaMedia"
                                name="Fatiga media"
                                stroke="#f59e0b"
                                strokeWidth={2}
                                dot
                            />
                        </LineChart>
                    </ResponsiveContainer>
                </div>
            </article>

            <article className="rounded-2xl bg-white p-6 shadow xl:col-span-2">
                <div className="mb-5">
                    <h2 className="text-xl font-semibold">Sensaciones registradas</h2>
                    <p className="mt-1 text-sm text-gray-600">
                        Comparativa diaria entre sensaciones fáciles, normales y difíciles.
                    </p>
                </div>

                <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={datos}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="fechaCorta" />
                            <YAxis />
                            <Tooltip />
                            <Bar dataKey="faciles" name="Fácil" fill="#16a34a" />
                            <Bar dataKey="bien" name="Bien" fill="#2563eb" />
                            <Bar dataKey="dificiles" name="Difícil" fill="#dc2626" />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </article>
        </section>
    );
}