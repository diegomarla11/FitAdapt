import { redirect } from "next/navigation";
import { crearClienteSupabaseServer } from "@/lib/supabase/server";
import { iniciarSesion, registrarse } from "./acciones";

export const dynamic = "force-dynamic";

type Props = {
  searchParams?: Promise<{
    error?: string;
    mensaje?: string;
  }>;
};

export default async function PaginaLogin({ searchParams }: Props) {
  const params = searchParams ? await searchParams : {};
  const error = params?.error ?? "";
  const mensaje = params?.mensaje ?? "";

  const supabase = await crearClienteSupabaseServer();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (user) {
    redirect("/inicio");
  }

  return (
    <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
      <div className="mx-auto grid max-w-6xl gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <section className="rounded-2xl bg-white p-8 shadow">
          <p className="mb-2 text-sm font-medium text-gray-500">TFG App</p>
          <h1 className="mb-4 text-4xl font-bold">Entrenamiento personalizado</h1>
          <p className="max-w-2xl text-gray-600">
            Guarda tu perfil, genera rutinas adaptadas a tu equipamiento,
            registra sesiones de entrenamiento y consulta tu progreso.
          </p>

          <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
            <article className="rounded-xl border p-4">
              <p className="text-sm text-gray-500">Perfil</p>
              <p className="mt-2 font-semibold">Configuración personalizada</p>
            </article>

            <article className="rounded-xl border p-4">
              <p className="text-sm text-gray-500">Rutinas</p>
              <p className="mt-2 font-semibold">Adaptadas a tu caso</p>
            </article>

            <article className="rounded-xl border p-4">
              <p className="text-sm text-gray-500">Progreso</p>
              <p className="mt-2 font-semibold">Seguimiento real</p>
            </article>
          </div>
        </section>

        <section className="rounded-2xl bg-white p-8 shadow">
          <div>
            <h2 className="text-2xl font-bold">Acceso</h2>
            <p className="mt-2 text-gray-600">
              Inicia sesión o crea una cuenta para guardar tus datos.
            </p>
          </div>

          {error && (
            <div className="mt-6 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
              {error}
            </div>
          )}

          {mensaje && (
            <div className="mt-6 rounded-lg border border-green-200 bg-green-50 p-3 text-sm text-green-700">
              {mensaje}
            </div>
          )}

          <div className="mt-6 space-y-8">
            <form action={iniciarSesion} className="space-y-4">
              <div>
                <label className="mb-1 block text-sm text-gray-600">Email</label>
                <input
                  type="email"
                  name="email"
                  className="w-full rounded-lg border p-3"
                  placeholder="tuemail@ejemplo.com"
                  required
                />
              </div>

              <div>
                <label className="mb-1 block text-sm text-gray-600">Contraseña</label>
                <input
                  type="password"
                  name="password"
                  className="w-full rounded-lg border p-3"
                  placeholder="******"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full rounded-lg bg-black px-5 py-3 text-white"
              >
                Iniciar sesión
              </button>
            </form>

            <div className="border-t pt-6">
              <p className="mb-4 text-sm text-gray-600">
                ¿No tienes cuenta? Créala aquí.
              </p>

              <form action={registrarse} className="space-y-4">
                <div>
                  <label className="mb-1 block text-sm text-gray-600">Email</label>
                  <input
                    type="email"
                    name="email"
                    className="w-full rounded-lg border p-3"
                    placeholder="tuemail@ejemplo.com"
                    required
                  />
                </div>

                <div>
                  <label className="mb-1 block text-sm text-gray-600">Contraseña</label>
                  <input
                    type="password"
                    name="password"
                    className="w-full rounded-lg border p-3"
                    placeholder="mínimo 6 caracteres"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full rounded-lg border px-5 py-3 hover:bg-gray-50"
                >
                  Crear cuenta
                </button>
              </form>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}