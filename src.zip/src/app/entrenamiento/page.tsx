import Link from "next/link";
import EntrenamientoActual from "@/componentes/entrenamientoActual";
import { obtenerEntrenamientoActual } from "@/lib/entrenamiento/obtenerEntrenamientoActual";
import { obtenerSesionesRutina } from "@/lib/entrenamiento/obtenerSesionesRutina";
import CabeceraPagina from "@/componentes/cabeceraPagina";
import { obtenerUsuarioActual } from "@/lib/auth/obtenerUsuarioActual";

export default async function PaginaEntrenamiento() {
  await obtenerUsuarioActual();

  const resultado = await obtenerEntrenamientoActual();

  const sesionesGuardadas = resultado
    ? await obtenerSesionesRutina(resultado.rutina.id)
    : [];

  if (!resultado) {
    return (
      <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
        <div className="mx-auto max-w-6xl space-y-6">
          <CabeceraPagina
            titulo="Entrenamiento"
            descripcion="Sigue la sesión actual y guarda tu actividad."
            acciones={
              <Link
                href="/rutina?modo=nueva"
                className="rounded-lg bg-black px-5 py-3 text-white"
              >
                Generar rutina
              </Link>
            }
          />

          <section className="rounded-2xl bg-white p-8 shadow">
            <p className="text-gray-600">
              Todavía no hay ninguna rutina guardada.
            </p>
          </section>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
      <div className="mx-auto max-w-6xl space-y-6">
        <CabeceraPagina
          titulo="Entrenamiento"
          descripcion="Marca los ejercicios realizados, guarda la sesión y registra tus datos reales."
          acciones={
            <Link
              href="/progreso"
              className="rounded-lg border px-5 py-3 hover:bg-gray-50"
            >
              Ver progreso
            </Link>
          }
        />

        <section className="rounded-2xl bg-white p-8 shadow">
          <EntrenamientoActual
            rutinaId={resultado.rutina.id}
            dias={resultado.dias}
            sesionesGuardadas={sesionesGuardadas}
          />
        </section>
      </div>
    </main>
  );
}