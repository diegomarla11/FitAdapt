import CabeceraPagina from "@/componentes/cabeceraPagina";
import { obtenerDatosProgreso } from "@/lib/progreso/obtenerDatosProgreso";
import PanelProgresoVisual from "@/componentes/panelProgresoVisual";
import { obtenerUsuarioActual } from "@/lib/auth/obtenerUsuarioActual";
import PanelGraficasHistoricas from "@/componentes/panelGraficasHistoricas";

function formatearPorcentaje(valor: number) {
  return `${Math.round(valor * 100)}%`;
}

function formatearNumero(valor: number | null, decimales = 1) {
  if (valor === null || !Number.isFinite(valor)) {
    return "-";
  }

  return valor.toFixed(decimales);
}

function formatearSegundos(valor: number | null) {
  if (valor === null || !Number.isFinite(valor)) {
    return "-";
  }

  return `${Math.round(valor)} s`;
}

function obtenerDiagnosticoProgreso(
  resumenGlobal: {
    sesionesTotales: number;
    ejerciciosTotales: number;
    seriesTotales: number;
    pesoTotalRegistrado: number;
    faciles: number;
    dificiles: number;
  } | null,
  resumenPorEjercicio: {
    estado:
    | "muy_bien"
    | "bien"
    | "neutro"
    | "fatiga"
    | "bajo_rendimiento"
    | "dolor"
    | "sin_datos";
  }[]
) {
  if (!resumenGlobal || resumenGlobal.sesionesTotales === 0) {
    return {
      titulo: "Sin datos suficientes",
      descripcion:
        "Todavía no hay sesiones suficientes para interpretar el progreso. Registra varios entrenamientos para obtener una valoración más fiable.",
      recomendacion:
        "Completa al menos varias sesiones usando los datos reales de series, repeticiones, peso y sensación.",
    };
  }

  const ejerciciosConFatiga = resumenPorEjercicio.filter(
    (ejercicio) =>
      ejercicio.estado === "fatiga" ||
      ejercicio.estado === "bajo_rendimiento"
  ).length;

  const ejerciciosConDolor = resumenPorEjercicio.filter(
    (ejercicio) => ejercicio.estado === "dolor"
  ).length;

  const ejerciciosConBuenEstado = resumenPorEjercicio.filter(
    (ejercicio) =>
      ejercicio.estado === "muy_bien" ||
      ejercicio.estado === "bien"
  ).length;

  if (ejerciciosConDolor > 0) {
    return {
      titulo: "Atención al dolor",
      descripcion:
        "Se han detectado señales de dolor en uno o varios ejercicios recientes. Esto puede indicar que alguna variante, carga o patrón de movimiento no está siendo bien tolerado.",
      recomendacion:
        "Prioriza cambiar variantes conflictivas, reducir exigencia y evitar progresar en ejercicios donde aparezca dolor repetido.",
    };
  }

  if (ejerciciosConFatiga >= 2 || resumenGlobal.dificiles > resumenGlobal.faciles) {
    return {
      titulo: "Atención a la fatiga",
      descripcion:
        "Hay señales de dificultad acumulada en algunos ejercicios o sesiones. Esto puede indicar que conviene controlar la exigencia antes de seguir aumentando volumen o intensidad.",
      recomendacion:
        "Prioriza mantener cargas, cuidar la técnica y revisar los ejercicios marcados como difíciles o con bajo rendimiento.",
    };
  }

  if (ejerciciosConBuenEstado >= 3 && resumenGlobal.faciles >= resumenGlobal.dificiles) {
    return {
      titulo: "Progreso estable",
      descripcion:
        "La mayoría de registros muestran cumplimiento correcto y sensaciones controladas. El entrenamiento parece estar respondiendo bien al perfil actual.",
      recomendacion:
        "Puedes seguir con la rutina actual y aplicar progresiones moderadas en ejercicios que se repitan con buena sensación.",
    };
  }

  return {
    titulo: "Progreso neutro",
    descripcion:
      "Los datos muestran una evolución equilibrada, sin señales claras de fatiga elevada ni de progresión destacada.",
    recomendacion:
      "Continúa registrando sesiones para que la aplicación pueda detectar tendencias más claras.",
  };
}

function formatearEstado(
  estado:
    | "muy_bien"
    | "bien"
    | "neutro"
    | "fatiga"
    | "bajo_rendimiento"
    | "dolor"
    | "sin_datos"
) {
  switch (estado) {
    case "muy_bien":
      return "Muy bien";
    case "bien":
      return "Bien";
    case "neutro":
      return "Neutro";
    case "fatiga":
      return "Fatiga";
    case "bajo_rendimiento":
      return "Bajo rendimiento";
    case "dolor":
      return "Dolor";
    default:
      return "Sin datos";
  }
}

export default async function PaginaProgreso() {
  await obtenerUsuarioActual();

  const {
    resumenGlobal,
    resumenPorGrupo,
    resumenPorEjercicio,
    evolucionProgreso, 
    ultimasSesiones,
  } = await obtenerDatosProgreso();

  const resumenGlobalVisual = resumenGlobal
    ? {
      sesionesTotales: resumenGlobal.sesionesTotales,
      ejerciciosTotales: resumenGlobal.ejerciciosTotales,
      seriesTotales: resumenGlobal.seriesTotales,
      pesoTotalRegistrado: resumenGlobal.pesoTotalRegistrado,
      sensacionesFaciles: resumenGlobal.faciles,
      sensacionesDificiles: resumenGlobal.dificiles,
    }
    : null;

  const resumenPorGrupoVisual = resumenPorGrupo.map((grupo) => ({
    grupo: grupo.grupoMuscular,
    apariciones: grupo.aparicionesTotales,
    cumplimiento: grupo.cumplimientoMedio * 100,
    ratioSeries: grupo.ratioSeriesMedio,
    sensacionDominante: grupo.sensacionDominante ?? "-",
  }));

  const resumenPorEjercicioVisual = resumenPorEjercicio.map((ejercicio) => ({
    ejercicio: ejercicio.nombreEjercicio,
    grupo: ejercicio.grupoMuscular,
    apariciones: ejercicio.apariciones,
    cumplimiento: ejercicio.cumplimiento * 100,
    ratioSeries: ejercicio.ratioSeries,
    pesoMedio: ejercicio.pesoMedio,
    dolorMedio: ejercicio.dolorMedio,
    fatigaMedia: ejercicio.fatigaMedia,
    descansoRecomendadoMedio: ejercicio.descansoRecomendadoMedio,
    descansoRealMedio: ejercicio.descansoRealMedio,
    ratioDescanso: ejercicio.ratioDescanso,
    estado: formatearEstado(ejercicio.estado),
  }));

  const diagnosticoProgreso = obtenerDiagnosticoProgreso(
    resumenGlobal,
    resumenPorEjercicio
  );

  return (
    <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
      <div className="mx-auto max-w-6xl space-y-6">
        <CabeceraPagina
          titulo="Progreso"
          descripcion="Consulta el estado general de tu entrenamiento, el rendimiento por ejercicio y la evolución reciente."
        />

        {!resumenGlobal ? (
          <section className="rounded-2xl bg-white p-8 shadow">
            <p className="text-gray-600">
              No hay datos suficientes para mostrar el progreso.
            </p>
          </section>
        ) : (
          <>
            <section className="rounded-2xl border border-blue-200 bg-blue-50 p-6 shadow">
              <p className="text-sm font-medium text-blue-700">
                Diagnóstico automático
              </p>

              <h2 className="mt-2 text-2xl font-semibold text-blue-950">
                {diagnosticoProgreso.titulo}
              </h2>

              <p className="mt-3 text-sm text-blue-900">
                {diagnosticoProgreso.descripcion}
              </p>

              <div className="mt-4 rounded-xl border border-blue-200 bg-white p-4">
                <p className="text-sm font-semibold text-blue-950">
                  Recomendación
                </p>
                <p className="mt-1 text-sm text-blue-900">
                  {diagnosticoProgreso.recomendacion}
                </p>
              </div>
            </section>
            <section className="grid grid-cols-1 gap-4 md:grid-cols-3 lg:grid-cols-6">
              <article className="rounded-2xl bg-white p-5 shadow">
                <p className="text-sm text-gray-500">Sesiones</p>
                <p className="mt-2 text-2xl font-semibold">
                  {resumenGlobal.sesionesTotales}
                </p>
              </article>

              <article className="rounded-2xl bg-white p-5 shadow">
                <p className="text-sm text-gray-500">Ejercicios</p>
                <p className="mt-2 text-2xl font-semibold">
                  {resumenGlobal.ejerciciosTotales}
                </p>
              </article>

              <article className="rounded-2xl bg-white p-5 shadow">
                <p className="text-sm text-gray-500">Series</p>
                <p className="mt-2 text-2xl font-semibold">
                  {resumenGlobal.seriesTotales}
                </p>
              </article>

              <article className="rounded-2xl bg-white p-5 shadow">
                <p className="text-sm text-gray-500">Suma de pesos registrados</p>
                <p className="mt-2 text-2xl font-semibold">
                  {resumenGlobal.pesoTotalRegistrado}
                </p>
              </article>

              <article className="rounded-2xl bg-white p-5 shadow">
                <p className="text-sm text-gray-500">Sensación fácil</p>
                <p className="mt-2 text-2xl font-semibold">
                  {resumenGlobal.faciles}
                </p>
              </article>

              <article className="rounded-2xl bg-white p-5 shadow">
                <p className="text-sm text-gray-500">Sensación difícil</p>
                <p className="mt-2 text-2xl font-semibold">
                  {resumenGlobal.dificiles}
                </p>
              </article>
            </section>

            <PanelGraficasHistoricas evolucion={evolucionProgreso} />

            <PanelProgresoVisual
              resumenGlobal={resumenGlobalVisual}
              resumenPorGrupo={resumenPorGrupoVisual}
              resumenPorEjercicio={resumenPorEjercicioVisual}
            />

            <section className="grid grid-cols-1 gap-6 xl:grid-cols-2">
              <article className="rounded-2xl bg-white p-6 shadow">
                <h2 className="text-xl font-semibold">Resumen por grupo muscular</h2>

                {resumenPorGrupo.length === 0 ? (
                  <p className="mt-4 text-sm text-gray-500">
                    Todavía no hay datos por grupo muscular.
                  </p>
                ) : (
                  <div className="mt-4 space-y-3">
                    {resumenPorGrupo.map((grupo) => (
                      <div key={grupo.grupoMuscular} className="rounded-xl border p-4">
                        <div className="grid grid-cols-1 gap-3 md:grid-cols-5">
                          <div>
                            <p className="text-xs text-gray-500">Grupo</p>
                            <p className="mt-1 font-medium capitalize">
                              {grupo.grupoMuscular}
                            </p>
                          </div>

                          <div>
                            <p className="text-xs text-gray-500">Apariciones</p>
                            <p className="mt-1 font-medium">
                              {grupo.aparicionesTotales}
                            </p>
                          </div>

                          <div>
                            <p className="text-xs text-gray-500">Cumplimiento</p>
                            <p className="mt-1 font-medium">
                              {formatearPorcentaje(grupo.cumplimientoMedio)}
                            </p>
                          </div>

                          <div>
                            <p className="text-xs text-gray-500">Ratio series</p>
                            <p className="mt-1 font-medium">
                              {grupo.ratioSeriesMedio.toFixed(2)}
                            </p>
                          </div>

                          <div>
                            <p className="text-xs text-gray-500">Sensación</p>
                            <p className="mt-1 font-medium">
                              {grupo.sensacionDominante ?? "-"}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </article>

              <article className="rounded-2xl bg-white p-6 shadow">
                <h2 className="text-xl font-semibold">Últimas sesiones</h2>

                {ultimasSesiones.length === 0 ? (
                  <p className="mt-4 text-sm text-gray-500">
                    Todavía no hay sesiones registradas.
                  </p>
                ) : (
                  <div className="mt-4 space-y-3">
                    {ultimasSesiones.map((sesion) => (
                      <div key={sesion.id} className="rounded-xl border p-4">
                        <p className="font-medium">{sesion.titulo_dia}</p>
                        <p className="mt-1 text-sm text-gray-600">
                          Fecha: {sesion.fecha}
                        </p>
                        <p className="mt-1 text-sm text-gray-600">
                          Nota: {sesion.nota_sesion ?? "Sin nota"}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </article>
            </section>

            <section className="rounded-2xl bg-white p-6 shadow">
              <h2 className="text-xl font-semibold">Resumen por ejercicio</h2>

              {resumenPorEjercicio.length === 0 ? (
                <p className="mt-4 text-sm text-gray-500">
                  Todavía no hay suficientes datos por ejercicio.
                </p>
              ) : (
                <div className="mt-4 space-y-3">
                  {resumenPorEjercicio.map((ejercicio) => (
                    <div key={ejercicio.ejercicioId} className="rounded-xl border p-4">
                      <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
                        <div>
                          <p className="text-xs text-gray-500">Ejercicio</p>
                          <p className="mt-1 font-medium">
                            {ejercicio.nombreEjercicio}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs text-gray-500">Grupo</p>
                          <p className="mt-1 font-medium capitalize">
                            {ejercicio.grupoMuscular}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs text-gray-500">Apariciones</p>
                          <p className="mt-1 font-medium">
                            {ejercicio.apariciones}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs text-gray-500">Cumplimiento</p>
                          <p className="mt-1 font-medium">
                            {formatearPorcentaje(ejercicio.cumplimiento)}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs text-gray-500">Ratio series</p>
                          <p className="mt-1 font-medium">
                            {ejercicio.ratioSeries.toFixed(2)}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs text-gray-500">Peso medio</p>
                          <p className="mt-1 font-medium">
                            {ejercicio.pesoMedio ?? "-"}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs text-gray-500">Estado</p>
                          <p className="mt-1 font-medium">
                            {formatearEstado(ejercicio.estado)}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs text-gray-500">Dolor medio</p>
                          <p className="mt-1 font-medium">
                            {formatearNumero(ejercicio.dolorMedio)}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs text-gray-500">Fatiga media</p>
                          <p className="mt-1 font-medium">
                            {formatearNumero(ejercicio.fatigaMedia)}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs text-gray-500">Descanso recomendado medio</p>
                          <p className="mt-1 font-medium">
                            {formatearSegundos(ejercicio.descansoRecomendadoMedio)}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs text-gray-500">Descanso real medio</p>
                          <p className="mt-1 font-medium">
                            {formatearSegundos(ejercicio.descansoRealMedio)}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs text-gray-500">Ratio descanso</p>
                          <p className="mt-1 font-medium">
                            {formatearNumero(ejercicio.ratioDescanso, 2)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </>
        )}
      </div>
    </main>
  );
}