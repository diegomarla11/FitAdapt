import { crearClienteSupabaseServer } from "@/lib/supabase/server";
import { generarRutinaBasica } from "@/lib/rutina/generadorRutina";
import {
    obtenerUltimaRutinaGuardada,
    obtenerUltimoPerfil,
} from "@/lib/rutina/obtenerUltimaRutina";
import { transformarRutinaGuardada } from "@/lib/rutina/transformarRutinaGuardada";
import type { Perfil } from "@/tipos/perfil";
import type { Ejercicio } from "@/tipos/ejercicio";
import { obtenerSiguienteIndiceRotacion } from "@/lib/rutina/obtenerIndiceRotacion";
import RutinaEditable from "@/componentes/rutinaEditable";
import { comprobarRutinaDesactualizada } from "@/lib/rutina/comprobarRutinaDesactualizada";
import Link from "next/link";
import CabeceraPagina from "@/componentes/cabeceraPagina";
import { obtenerUsuarioActual } from "@/lib/auth/obtenerUsuarioActual";

type Props = {
    searchParams?: Promise<{
        modo?: string;
        rotacion?: string;
    }>;
};

function obtenerListaEquipamiento(equipoDisponible: string | null | undefined) {
    if (!equipoDisponible || !equipoDisponible.trim()) {
        return ["No indicado"];
    }

    return equipoDisponible
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean);
}

function obtenerTextoMolestias(molestias: string | null | undefined) {
    if (!molestias || !molestias.trim() || molestias === "No indicadas") {
        return "No indicadas";
    }

    return molestias;
}

function normalizarTexto(valor: string | null | undefined) {
    return valor?.trim().toLowerCase() ?? "";
}

function obtenerDescripcionObjetivo(objetivo: string) {
    const objetivoNormalizado = normalizarTexto(objetivo);

    if (objetivoNormalizado === "fuerza") {
        return "Se priorizan rangos de repeticiones más bajos en ejercicios principales y se controla el volumen accesorio.";
    }

    if (objetivoNormalizado === "hipertrofia") {
        return "Se priorizan rangos medios y altos de repeticiones para acumular volumen de trabajo.";
    }

    if (objetivoNormalizado === "mantenimiento") {
        return "Se reduce ligeramente el volumen para mantener estímulo sin generar una carga excesiva.";
    }

    if (
        objetivoNormalizado === "recomposicion" ||
        objetivoNormalizado === "recomposición"
    ) {
        return "Se usa un volumen moderado con rangos medios para equilibrar estímulo muscular y recuperación.";
    }

    return "El objetivo se usa para ajustar volumen, repeticiones y tipo de estímulo.";
}

function obtenerDescripcionNivel(nivel: string) {
    const nivelNormalizado = normalizarTexto(nivel);

    if (nivelNormalizado === "principiante") {
        return "Se priorizan ejercicios de dificultad principiante y un volumen más controlado.";
    }

    if (nivelNormalizado === "avanzado") {
        return "Se permiten ejercicios más exigentes y algo más de volumen en movimientos principales.";
    }

    return "Se usan ejercicios y volúmenes intermedios, manteniendo una progresión equilibrada.";
}

function obtenerDescripcionDuracion(duracionSesion: number) {
    if (duracionSesion <= 30) {
        return "Sesión corta: se priorizan ejercicios principales y se pueden reducir accesorios.";
    }

    if (duracionSesion <= 60) {
        return "Duración estándar: se mantiene una combinación equilibrada de ejercicios principales y accesorios.";
    }

    return "Sesión amplia: permite conservar más volumen y más ejercicios accesorios si el perfil lo permite.";
}

function SeccionExplicacionAdaptacion({
    perfil,
    indiceRotacion,
    modo,
}: {
    perfil: Perfil;
    indiceRotacion: number;
    modo: "guardada" | "generada";
}) {
    const equipamiento = obtenerListaEquipamiento(perfil.equipo_disponible);
    const molestias = obtenerTextoMolestias(perfil.molestias);

    return (
        <details className="rounded-2xl border bg-white p-5 shadow">
            <summary className="cursor-pointer list-none">
                <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                    <div>
                        <p className="text-sm font-medium text-gray-500">
                            Sistema de adaptación
                        </p>
                        <h2 className="text-lg font-semibold">
                            Resumen de adaptación
                        </h2>
                        <p className="mt-1 text-sm text-gray-600">
                            {perfil.objetivo} · {perfil.dias_por_semana} días · {perfil.nivel} · {perfil.duracion_sesion} min
                        </p>
                    </div>

                    <span className="rounded-lg border px-4 py-2 text-sm hover:bg-gray-50">
                        Ver detalles
                    </span>
                </div>
            </summary>

            <div className="mt-5 space-y-5">
                <p className="text-sm text-gray-600">
                    La rutina se construye usando el objetivo, el nivel, la duración disponible,
                    el equipamiento, las molestias, la rotación de ejercicios y los datos de progreso registrados.
                </p>

                <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                    <article className="rounded-xl border p-4">
                        <p className="text-sm text-gray-500">Objetivo</p>
                        <p className="mt-1 font-semibold capitalize">{perfil.objetivo}</p>
                        <p className="mt-2 text-sm text-gray-600">
                            {obtenerDescripcionObjetivo(perfil.objetivo)}
                        </p>
                    </article>

                    <article className="rounded-xl border p-4">
                        <p className="text-sm text-gray-500">Frecuencia semanal</p>
                        <p className="mt-1 font-semibold">
                            {perfil.dias_por_semana} días por semana
                        </p>
                        <p className="mt-2 text-sm text-gray-600">
                            La división semanal se adapta al número de días indicado.
                        </p>
                    </article>

                    <article className="rounded-xl border p-4">
                        <p className="text-sm text-gray-500">Nivel</p>
                        <p className="mt-1 font-semibold capitalize">{perfil.nivel}</p>
                        <p className="mt-2 text-sm text-gray-600">
                            {obtenerDescripcionNivel(perfil.nivel)}
                        </p>
                    </article>
                </div>

                <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                    <article className="rounded-xl border bg-gray-50 p-4">
                        <p className="text-sm text-gray-500">Duración</p>
                        <p className="mt-1 font-semibold">{perfil.duracion_sesion} minutos</p>
                        <p className="mt-2 text-sm text-gray-600">
                            {obtenerDescripcionDuracion(perfil.duracion_sesion)}
                        </p>
                    </article>

                    <article className="rounded-xl border bg-gray-50 p-4">
                        <p className="text-sm text-gray-500">Estado</p>
                        <p className="mt-1 font-semibold">
                            {modo === "guardada" ? "Rutina guardada" : "Rutina generada"}
                        </p>
                    </article>

                    <article className="rounded-xl border bg-gray-50 p-4">
                        <p className="text-sm text-gray-500">Rotación</p>
                        <p className="mt-1 font-semibold">Índice {indiceRotacion}</p>
                    </article>
                </div>

                <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
                    <article className="rounded-xl border bg-gray-50 p-4">
                        <p className="text-sm font-medium text-gray-700">
                            Equipamiento usado
                        </p>

                        <div className="mt-3 flex flex-wrap gap-2">
                            {equipamiento.map((item) => (
                                <span
                                    key={item}
                                    className="rounded-full border bg-white px-3 py-1 text-sm capitalize text-gray-700"
                                >
                                    {item}
                                </span>
                            ))}
                        </div>
                    </article>

                    <article className="rounded-xl border bg-gray-50 p-4">
                        <p className="text-sm font-medium text-gray-700">
                            Molestias consideradas
                        </p>
                        <p className="mt-3 text-sm text-gray-700">{molestias}</p>
                    </article>
                </div>
            </div>
        </details>
    );
}

export default async function PaginaRutina({ searchParams }: Props) {
    await obtenerUsuarioActual();

    const params = searchParams ? await searchParams : {};
    const modo = params?.modo;
    const rotacionDesdeUrl = Number(params?.rotacion ?? "");

    const perfil = (await obtenerUltimoPerfil()) as Perfil | null;
    const supabase = await crearClienteSupabaseServer();
    const { data: ejercicios, error: errorEjercicios } = await supabase
        .from("ejercicios")
        .select("*")
        .order("nombre", { ascending: true });

    if (errorEjercicios) {
        return (
            <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
                <div className="mx-auto max-w-6xl space-y-6">
                    <CabeceraPagina
                        titulo="Rutina"
                        descripcion="Genera, revisa y edita tu rutina personalizada."
                    />

                    <section className="rounded-2xl bg-white p-8 shadow">
                        <p className="text-red-600">
                            Ha ocurrido un error al generar la rutina.
                        </p>
                    </section>
                </div>
            </main>
        );
    }

    const listaEjercicios: Ejercicio[] = ejercicios ?? [];

    if (!perfil) {
        return (
            <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
                <div className="mx-auto max-w-6xl space-y-6">
                    <CabeceraPagina
                        titulo="Rutina"
                        descripcion="Genera, revisa y edita tu rutina personalizada."
                        acciones={
                            <Link
                                href="/onboarding"
                                className="rounded-lg bg-black px-5 py-3 text-white"
                            >
                                Completar onboarding
                            </Link>
                        }
                    />

                    <section className="rounded-2xl bg-white p-8 shadow">
                        <p className="text-gray-600">
                            No hay perfil guardado. Completa primero el onboarding.
                        </p>
                    </section>
                </div>
            </main>
        );
    }

    if (listaEjercicios.length === 0) {
        return (
            <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
                <div className="mx-auto max-w-6xl space-y-6">
                    <CabeceraPagina
                        titulo="Rutina"
                        descripcion="Genera, revisa y edita tu rutina personalizada."
                    />

                    <section className="rounded-2xl bg-white p-8 shadow">
                        <p className="text-gray-600">
                            No hay ejercicios disponibles para generar la rutina.
                        </p>
                    </section>
                </div>
            </main>
        );
    }

    if (modo !== "nueva") {
        const rutinaGuardada = await obtenerUltimaRutinaGuardada();

        if (rutinaGuardada) {
            const rutinaTransformada = transformarRutinaGuardada(
                rutinaGuardada.rutina,
                rutinaGuardada.ejercicios
            );

            const rutinaDesactualizada = comprobarRutinaDesactualizada(
                perfil,
                rutinaGuardada.rutina
            );

            return (
                <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
                    <div className="mx-auto max-w-6xl space-y-6">
                        <CabeceraPagina
                            titulo="Rutina guardada"
                            descripcion={`Objetivo: ${rutinaTransformada.objetivo} · Nivel: ${rutinaTransformada.nivel} · Días por semana: ${rutinaTransformada.dias_por_semana}`}
                            acciones={
                                <>
                                    <Link
                                        href="/rutina?modo=nueva"
                                        className="rounded-lg border px-5 py-3 hover:bg-gray-50"
                                    >
                                        Regenerar rutina
                                    </Link>

                                    <Link
                                        href="/inicio"
                                        className="rounded-lg border px-5 py-3 hover:bg-gray-50"
                                    >
                                        Volver al inicio
                                    </Link>
                                </>
                            }
                        />

                        {rutinaDesactualizada && (
                            <section className="rounded-2xl border border-yellow-300 bg-yellow-50 p-4 shadow">
                                <h2 className="text-lg font-semibold text-yellow-800">
                                    Esta rutina puede estar desactualizada
                                </h2>
                                <p className="mt-2 text-sm text-yellow-700">
                                    El perfil ha cambiado desde que se guardó esta rutina. Puedes revisarla, editarla o regenerarla.
                                </p>

                                <div className="mt-4 flex flex-wrap gap-3">
                                    <Link
                                        href="/perfil"
                                        className="rounded-lg border border-yellow-700 px-4 py-2 text-yellow-800 hover:bg-yellow-100"
                                    >
                                        Revisar perfil
                                    </Link>

                                    <Link
                                        href="/rutina?modo=nueva"
                                        className="rounded-lg bg-black px-4 py-2 text-white"
                                    >
                                        Regenerar rutina
                                    </Link>
                                </div>
                            </section>
                        )}

                        <SeccionExplicacionAdaptacion
                            perfil={perfil}
                            indiceRotacion={rutinaGuardada.rutina.indice_rotacion ?? 0}
                            modo="guardada"
                        />

                        <section className="rounded-2xl bg-white p-8 shadow">
                            {perfil.equipo_disponible && (
                                <p className="mb-6 text-sm text-gray-600">
                                    Rutina adaptada según el equipamiento disponible:{" "}
                                    {perfil.equipo_disponible.split(",").join(", ")}
                                </p>
                            )}

                            {perfil.molestias && perfil.molestias !== "No indicadas" && (
                                <p className="mb-6 text-sm text-gray-600">
                                    Rutina adaptada según las molestias indicadas: {perfil.molestias}
                                </p>
                            )}

                            <RutinaEditable
                                rutinaInicial={rutinaTransformada}
                                ejerciciosDisponibles={listaEjercicios}
                                equipamientoDisponiblePerfil={perfil.equipo_disponible ?? null}
                                molestiasPerfil={perfil.molestias ?? null}
                                rutinaIdExistente={rutinaGuardada.rutina.id}
                            />
                        </section>
                    </div>
                </main>
            );
        }
    }

    const indiceRotacion =
        Number.isFinite(rotacionDesdeUrl) && rotacionDesdeUrl >= 0
            ? rotacionDesdeUrl
            : await obtenerSiguienteIndiceRotacion();

    const rutina = await generarRutinaBasica(
        perfil,
        listaEjercicios,
        indiceRotacion,
    );

    return (
        <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
            <div className="mx-auto max-w-6xl space-y-6">
                <CabeceraPagina
                    titulo="Rutina generada"
                    descripcion={`Rutina generada pendiente de guardar · Objetivo: ${rutina.objetivo} · Nivel: ${rutina.nivel} · Días por semana: ${rutina.dias_por_semana}`}
                    acciones={
                        <>
                            <Link
                                href="/rutina?modo=nueva"
                                className="rounded-lg border px-5 py-3 hover:bg-gray-50"
                            >
                                Regenerar rutina
                            </Link>

                            <Link
                                href="/inicio"
                                className="rounded-lg border px-5 py-3 hover:bg-gray-50"
                            >
                                Volver al inicio
                            </Link>
                        </>
                    }
                />

                <SeccionExplicacionAdaptacion
                    perfil={perfil}
                    indiceRotacion={indiceRotacion}
                    modo="generada"
                />

                <section className="rounded-2xl bg-white p-5 shadow">
                    {perfil.equipo_disponible && (
                        <p className="mb-6 text-sm text-gray-600">
                            Rutina adaptada según el equipamiento disponible:{" "}
                            {perfil.equipo_disponible.split(",").join(", ")}
                        </p>
                    )}

                    {perfil.molestias && perfil.molestias !== "No indicadas" && (
                        <p className="mb-6 text-sm text-gray-600">
                            Rutina adaptada según las molestias indicadas: {perfil.molestias}
                        </p>
                    )}

                    <RutinaEditable
                        rutinaInicial={rutina}
                        ejerciciosDisponibles={listaEjercicios}
                        equipamientoDisponiblePerfil={perfil.equipo_disponible ?? null}
                        molestiasPerfil={perfil.molestias ?? null}
                        rutinaIdExistente={null}
                    />
                </section>
            </div>
        </main>
    );
}