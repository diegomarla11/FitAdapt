import Link from "next/link";
import { crearClienteSupabaseServer } from "@/lib/supabase/server";
import { parsearTextoLista } from "@/lib/ejercicios/parsearTextoLista";
import CabeceraPagina from "@/componentes/cabeceraPagina";
import type { Ejercicio } from "@/tipos/ejercicio";
import { obtenerUsuarioActual } from "@/lib/auth/obtenerUsuarioActual";
import Image from "next/image";

export const dynamic = "force-dynamic";

type Props = {
  params: Promise<{
    id: string;
  }>;
};

type RegistroHistorial = {
  id: string;
  created_at: string;
  series_reales: number | null;
  repeticiones_reales: string | null;
  peso_usado: number | null;
  sensacion: "facil" | "bien" | "dificil" | null;
  estado_resultado: "completado" | "parcial" | "superado" | null;
  nivel_dolor: number | null;
  fatiga: number | null;
  descanso_recomendado: number | null;
  descanso_real: number | null;
  motivo_parcial: string | null;
  sesiones_entrenamiento?:
    | {
        fecha: string;
        titulo_dia: string;
      }
    | {
        fecha: string;
        titulo_dia: string;
      }[]
    | null;
};

function formatearSensacion(sensacion: string | null) {
  if (sensacion === "facil") return "Fácil";
  if (sensacion === "bien") return "Bien";
  if (sensacion === "dificil") return "Difícil";
  return "No indicada";
}

function formatearEstadoResultado(estado: string | null) {
  if (estado === "completado") {
    return "Completado según lo previsto";
  }

  if (estado === "parcial") {
    return "Realizado por debajo de lo previsto";
  }

  if (estado === "superado") {
    return "Realizado por encima de lo previsto";
  }

  return "No indicado";
}

function formatearEscala(valor: number | null) {
  if (valor === null || !Number.isFinite(valor)) {
    return "-";
  }

  return `${valor}/10`;
}

function formatearDescanso(valor: number | null) {
  if (valor === null || !Number.isFinite(valor)) {
    return "-";
  }

  return `${Math.round(valor)} s`;
}

function obtenerSesionHistorial(
  sesiones:
    | {
        fecha: string;
        titulo_dia: string;
      }
    | {
        fecha: string;
        titulo_dia: string;
      }[]
    | null
    | undefined,
) {
  if (!sesiones) {
    return null;
  }

  if (Array.isArray(sesiones)) {
    return sesiones[0] ?? null;
  }

  return sesiones;
}

function obtenerLecturaHistorial(historial: RegistroHistorial[]) {
  if (historial.length === 0) {
    return {
      titulo: "Sin historial suficiente",
      descripcion:
        "Todavía no hay datos de entrenamiento para interpretar la evolución de este ejercicio.",
    };
  }

  const ultimoRegistro = historial[0];

  if ((ultimoRegistro.nivel_dolor ?? 0) >= 4) {
    return {
      titulo: "Dolor registrado recientemente",
      descripcion:
        "En el último registro aparece dolor relevante. Conviene evitar progresar en este ejercicio y valorar una variante menos conflictiva.",
    };
  }

  if ((ultimoRegistro.fatiga ?? 0) >= 8) {
    return {
      titulo: "Fatiga elevada recientemente",
      descripcion:
        "En el último registro aparece fatiga alta. Conviene mantener o reducir la exigencia antes de volver a progresar.",
    };
  }

  if (
    ultimoRegistro.descanso_recomendado &&
    ultimoRegistro.descanso_real &&
    ultimoRegistro.descanso_real / ultimoRegistro.descanso_recomendado >= 1.5
  ) {
    return {
      titulo: "Descanso real elevado",
      descripcion:
        "El último registro necesitó bastante más descanso del recomendado. Esto puede indicar fatiga o una exigencia demasiado alta.",
    };
  }

  if (ultimoRegistro.estado_resultado === "superado") {
    return {
      titulo: "Buen rendimiento reciente",
      descripcion:
        "En el último registro superaste lo previsto. Este ejercicio podría admitir una progresión suave si la técnica se mantiene correcta.",
    };
  }

  if (ultimoRegistro.estado_resultado === "parcial") {
    return {
      titulo: "Rendimiento por debajo de lo previsto",
      descripcion:
        "En el último registro no se alcanzó completamente lo planificado. Conviene mantener o reducir la exigencia antes de progresar.",
    };
  }

  if (ultimoRegistro.sensacion === "dificil") {
    return {
      titulo: "Ejercicio exigente recientemente",
      descripcion:
        "La última sensación registrada fue difícil. Prioriza la ejecución técnica y evita aumentar la carga demasiado pronto.",
    };
  }

  if (ultimoRegistro.sensacion === "facil") {
    return {
      titulo: "Ejercicio asimilado correctamente",
      descripcion:
        "La última sensación registrada fue fácil. Puedes valorar aumentar ligeramente la carga, las repeticiones o mantener una ejecución más controlada.",
    };
  }

  return {
    titulo: "Rendimiento estable",
    descripcion:
      "El historial reciente muestra una ejecución estable. Puedes repetir una carga similar y seguir registrando datos.",
  };
}

function SeccionTecnica({
  titulo,
  items,
  vacio,
}: {
  titulo: string;
  items: string[];
  vacio: string;
}) {
  return (
    <article className="rounded-2xl border bg-white p-5">
      <h2 className="text-base font-semibold">{titulo}</h2>

      {items.length > 0 ? (
        <ul className="mt-3 space-y-2 text-sm text-gray-700">
          {items.map((item, index) => (
            <li key={index} className="flex gap-2">
              <span className="mt-[2px] text-gray-400">•</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="mt-3 text-sm text-gray-500">{vacio}</p>
      )}
    </article>
  );
}

export default async function PaginaDetalleEjercicio({ params }: Props) {
  const { id } = await params;

  const supabase = await crearClienteSupabaseServer();

  const user = await obtenerUsuarioActual();

  const { data: ejercicioData, error } = await supabase
    .from("ejercicios")
    .select("*")
    .eq("id", id)
    .maybeSingle();

  const ejercicio = ejercicioData as Ejercicio | null;

  if (error || !ejercicio) {
    return (
      <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
        <div className="mx-auto max-w-5xl space-y-6">
          <CabeceraPagina
            titulo="Ejercicio no encontrado"
            descripcion="No se ha podido cargar la ficha solicitada."
            acciones={
              <Link
                href="/ejercicios"
                className="rounded-lg border px-5 py-3 hover:bg-gray-50"
              >
                Volver a ejercicios
              </Link>
            }
          />

          <section className="rounded-2xl bg-white p-8 shadow">
            <p className="text-red-600">
              No se ha podido cargar el detalle del ejercicio.
            </p>
          </section>
        </div>
      </main>
    );
  }

  let historial: RegistroHistorial[] = [];

  if (user) {
    const { data: sesionesUsuario, error: errorSesiones } = await supabase
      .from("sesiones_entrenamiento")
      .select("id")
      .eq("user_id", user.id);

    if (!errorSesiones && sesionesUsuario && sesionesUsuario.length > 0) {
      const idsSesiones = sesionesUsuario.map((sesion) => sesion.id);

      const { data: historialData } = await supabase
        .from("sesion_ejercicios")
        .select(
          `
  id,
  created_at,
  series_reales,
  repeticiones_reales,
  peso_usado,
  sensacion,
  estado_resultado,
  nivel_dolor,
  fatiga,
  descanso_recomendado,
  descanso_real,
  motivo_parcial,
  sesiones_entrenamiento (
    fecha,
    titulo_dia
  )
`,
        )
        .eq("ejercicio_id", id)
        .eq("completado", true)
        .in("sesion_id", idsSesiones)
        .order("created_at", { ascending: false })
        .limit(8);

      historial = historialData ?? [];
    }
  }

  const instrucciones = parsearTextoLista(ejercicio.instrucciones);
  const erroresComunes = parsearTextoLista(ejercicio.errores_comunes);
  const ajustes = parsearTextoLista(ejercicio.ajustes);
  const recomendaciones = parsearTextoLista(ejercicio.recomendaciones_nivel);
  const variantes = parsearTextoLista(ejercicio.variantes);
  const contraindicaciones = parsearTextoLista(ejercicio.contraindicaciones);

  const vecesRealizado = historial.length;
  const ultimoPeso =
    historial.find((item) => item.peso_usado !== null)?.peso_usado ?? "-";
  const ultimasSeries =
    historial.find((item) => item.series_reales !== null)?.series_reales ?? "-";
  const ultimaSensacion =
    historial.find((item) => item.sensacion)?.sensacion ?? null;
  const ultimoDolor =
    historial.find((item) => item.nivel_dolor !== null)?.nivel_dolor ?? null;

  const ultimaFatiga =
    historial.find((item) => item.fatiga !== null)?.fatiga ?? null;

  const ultimoDescansoReal =
    historial.find((item) => item.descanso_real !== null)?.descanso_real ??
    null;
  const lecturaHistorial = obtenerLecturaHistorial(historial);

  return (
    <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
      <div className="mx-auto max-w-5xl space-y-6">
        <CabeceraPagina
          titulo="Detalle del ejercicio"
          descripcion="Consulta la técnica, recomendaciones e historial reciente."
          acciones={
            <Link
              href="/rutina"
              className="rounded-lg border px-5 py-3 hover:bg-gray-50"
            >
              Ver rutina
            </Link>
          }
        />

        <section className="rounded-2xl border bg-white p-5 shadow">
          <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
            <div>
              <p className="text-sm text-gray-500">Ficha técnica</p>
              <h2 className="mt-1 text-xl font-semibold">{ejercicio.nombre}</h2>

              <p className="mt-2 max-w-3xl text-sm leading-6 text-gray-700">
                {ejercicio.descripcion ?? "Ficha técnica del ejercicio."}
              </p>
            </div>

            <Link
              href="/ejercicios"
              className="rounded-lg border px-4 py-2 text-sm hover:bg-gray-50"
            >
              Volver
            </Link>
          </div>

          {ejercicio.imagen_url && (
            <section className="rounded-2xl bg-white p-6 shadow">
              <div className="relative h-[360px] w-full overflow-hidden rounded-xl border bg-gray-100">
                <Image
                  src={ejercicio.imagen_url}
                  alt={`Demostración del ejercicio ${ejercicio.nombre}`}
                  fill
                  priority
                  sizes="(max-width: 1024px) 100vw, 960px"
                  className="object-contain"
                />
              </div>
            </section>
          )}

          <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4">
            <div className="rounded-xl border bg-gray-50 p-3">
              <p className="text-xs text-gray-500">Grupo</p>
              <p className="mt-1 text-sm font-semibold capitalize">
                {ejercicio.grupo_muscular}
              </p>
            </div>

            <div className="rounded-xl border bg-gray-50 p-3">
              <p className="text-xs text-gray-500">Patrón</p>
              <p className="mt-1 text-sm font-semibold capitalize">
                {ejercicio.patron_movimiento ?? "No indicado"}
              </p>
            </div>

            <div className="rounded-xl border bg-gray-50 p-3">
              <p className="text-xs text-gray-500">Equipamiento</p>
              <p className="mt-1 text-sm font-semibold">
                {ejercicio.equipamiento ?? "No indicado"}
              </p>
            </div>

            <div className="rounded-xl border bg-gray-50 p-3">
              <p className="text-xs text-gray-500">Dificultad</p>
              <p className="mt-1 text-sm font-semibold capitalize">
                {ejercicio.dificultad ?? "No indicada"}
              </p>
            </div>
          </div>
        </section>

        <section className="rounded-2xl border border-blue-200 bg-blue-50 p-5">
          <h2 className="text-base font-semibold text-blue-950">
            Lectura rápida
          </h2>

          <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-3">
            <div className="rounded-xl border border-blue-200 bg-white p-3">
              <p className="text-xs font-medium text-blue-700">Técnica</p>
              <p className="mt-1 text-sm text-blue-950">
                Revisa primero instrucciones y ajustes antes de aumentar carga.
              </p>
            </div>

            <div className="rounded-xl border border-blue-200 bg-white p-3">
              <p className="text-xs font-medium text-blue-700">Progresión</p>
              <p className="mt-1 text-sm text-blue-950">
                Usa el historial reciente para decidir si mantener, subir o
                reducir.
              </p>
            </div>

            <div className="rounded-xl border border-blue-200 bg-white p-3">
              <p className="text-xs font-medium text-blue-700">Seguridad</p>
              <p className="mt-1 text-sm text-blue-950">
                Si aparece dolor o fatiga alta, prioriza una variante más
                cómoda.
              </p>
            </div>
          </div>
        </section>

        <section className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <SeccionTecnica
            titulo="Instrucciones"
            items={instrucciones}
            vacio="Sin instrucciones detalladas todavía."
          />

          <SeccionTecnica
            titulo="Ajustes y colocación"
            items={ajustes}
            vacio="Sin ajustes específicos registrados."
          />

          <SeccionTecnica
            titulo="Errores comunes"
            items={erroresComunes}
            vacio="Sin errores comunes registrados."
          />

          <SeccionTecnica
            titulo="Recomendaciones por nivel"
            items={recomendaciones}
            vacio="Sin recomendaciones registradas."
          />

          <SeccionTecnica
            titulo="Variantes y alternativas"
            items={variantes}
            vacio="Sin variantes registradas."
          />

          <SeccionTecnica
            titulo="Contraindicaciones"
            items={contraindicaciones}
            vacio="Sin contraindicaciones registradas."
          />
        </section>

        <section className="rounded-2xl bg-white p-6 shadow">
          <h2 className="text-xl font-semibold">Historial reciente</h2>

          {historial.length > 0 ? (
            <div className="mt-4 space-y-4">
              <div className="rounded-xl border border-blue-200 bg-blue-50 p-4">
                <p className="text-sm font-semibold text-blue-900">
                  {lecturaHistorial.titulo}
                </p>
                <p className="mt-1 text-sm text-blue-800">
                  {lecturaHistorial.descripcion}
                </p>
              </div>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
                <article className="rounded-xl border p-4">
                  <p className="text-sm text-gray-500">Veces realizado</p>
                  <p className="mt-2 text-2xl font-semibold">
                    {vecesRealizado}
                  </p>
                </article>

                <article className="rounded-xl border p-4">
                  <p className="text-sm text-gray-500">Último peso usado</p>
                  <p className="mt-2 text-2xl font-semibold">{ultimoPeso}</p>
                </article>

                <article className="rounded-xl border p-4">
                  <p className="text-sm text-gray-500">Últimas series reales</p>
                  <p className="mt-2 text-2xl font-semibold">{ultimasSeries}</p>
                </article>

                <article className="rounded-xl border p-4">
                  <p className="text-sm text-gray-500">Última sensación</p>
                  <p className="mt-2 text-2xl font-semibold">
                    {formatearSensacion(ultimaSensacion)}
                  </p>
                </article>

                <article className="rounded-xl border p-4">
                  <p className="text-sm text-gray-500">Último dolor</p>
                  <p className="mt-2 text-2xl font-semibold">
                    {formatearEscala(ultimoDolor)}
                  </p>
                </article>

                <article className="rounded-xl border p-4">
                  <p className="text-sm text-gray-500">Última fatiga</p>
                  <p className="mt-2 text-2xl font-semibold">
                    {formatearEscala(ultimaFatiga)}
                  </p>
                </article>

                <article className="rounded-xl border p-4">
                  <p className="text-sm text-gray-500">Último descanso real</p>
                  <p className="mt-2 text-2xl font-semibold">
                    {formatearDescanso(ultimoDescansoReal)}
                  </p>
                </article>
              </div>

              <details className="rounded-xl border bg-gray-50 p-4">
                <summary className="cursor-pointer list-none text-sm font-semibold text-gray-800">
                  Ver registros recientes
                </summary>

                <div className="mt-4 space-y-3">
                  {historial.map((registro) => {
                    const sesion = obtenerSesionHistorial(
                      registro.sesiones_entrenamiento,
                    );

                    return (
                      <article
                        key={registro.id}
                        className="rounded-xl border bg-white p-4"
                      >
                        <div className="grid grid-cols-2 gap-3 text-sm md:grid-cols-4">
                          <div>
                            <p className="text-xs text-gray-500">Fecha</p>
                            <p className="mt-1 font-medium">
                              {sesion?.fecha ??
                                registro.created_at?.slice(0, 10) ??
                                "-"}
                            </p>
                          </div>

                          <div>
                            <p className="text-xs text-gray-500">Día</p>
                            <p className="mt-1 font-medium">
                              {sesion?.titulo_dia ?? "No indicado"}
                            </p>
                          </div>

                          <div>
                            <p className="text-xs text-gray-500">
                              Series / reps
                            </p>
                            <p className="mt-1 font-medium">
                              {registro.series_reales ?? "-"} /{" "}
                              {registro.repeticiones_reales ?? "-"}
                            </p>
                          </div>

                          <div>
                            <p className="text-xs text-gray-500">Peso</p>
                            <p className="mt-1 font-medium">
                              {registro.peso_usado ?? "-"}
                            </p>
                          </div>

                          <div>
                            <p className="text-xs text-gray-500">Sensación</p>
                            <p className="mt-1 font-medium">
                              {formatearSensacion(registro.sensacion ?? null)}
                            </p>
                          </div>

                          <div>
                            <p className="text-xs text-gray-500">Resultado</p>
                            <p className="mt-1 font-medium">
                              {formatearEstadoResultado(
                                registro.estado_resultado,
                              )}
                            </p>
                          </div>

                          <div>
                            <p className="text-xs text-gray-500">
                              Dolor / fatiga
                            </p>
                            <p className="mt-1 font-medium">
                              {formatearEscala(registro.nivel_dolor)} /{" "}
                              {formatearEscala(registro.fatiga)}
                            </p>
                          </div>

                          <div>
                            <p className="text-xs text-gray-500">Descanso</p>
                            <p className="mt-1 font-medium">
                              {formatearDescanso(registro.descanso_real)}
                            </p>
                          </div>
                        </div>

                        {registro.motivo_parcial && (
                          <p className="mt-3 rounded-lg bg-gray-50 p-3 text-sm text-gray-700">
                            {registro.motivo_parcial}
                          </p>
                        )}
                      </article>
                    );
                  })}
                </div>
              </details>
            </div>
          ) : (
            <p className="mt-4 text-sm text-gray-500">
              Todavía no hay historial reciente de este ejercicio.
            </p>
          )}
        </section>
      </div>
    </main>
  );
}
