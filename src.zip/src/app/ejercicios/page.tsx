import Link from "next/link";
import { crearClienteSupabaseServer } from "@/lib/supabase/server";
import ListaEjerciciosFiltrada from "@/componentes/listaEjerciciosFiltrada";
import CabeceraPagina from "@/componentes/cabeceraPagina";
import type { Ejercicio } from "@/tipos/ejercicio";
import { obtenerUsuarioActual } from "@/lib/auth/obtenerUsuarioActual";

export const dynamic = "force-dynamic";

export default async function PaginaEjercicios() {
  await obtenerUsuarioActual();
  const supabase = await crearClienteSupabaseServer();

  const { data: ejercicios, error } = await supabase
    .from("ejercicios")
    .select("*")
    .order("nombre", { ascending: true });

  if (error) {
    return (
      <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
        <div className="mx-auto max-w-6xl space-y-6">
          <CabeceraPagina
            titulo="Ejercicios"
            descripcion="Explora, filtra y consulta los ejercicios disponibles en la aplicación."
            acciones={
              <Link
                href="/rutina"
                className="rounded-lg border px-5 py-3 hover:bg-gray-50"
              >
                Ver rutina
              </Link>
            }
          />

          <section className="rounded-2xl bg-white p-8 shadow">
            <p className="text-red-600">
              No se ha podido cargar el listado de ejercicios.
            </p>
          </section>
        </div>
      </main>
    );
  }

  const listaEjercicios = (ejercicios ?? []) as Ejercicio[];

  return (
    <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
      <div className="mx-auto max-w-6xl space-y-6">
        <CabeceraPagina
          titulo="Ejercicios"
          descripcion="Explora, filtra y consulta los ejercicios de la aplicación."
          acciones={
            <Link
              href="/rutina"
              className="rounded-lg border px-5 py-3 hover:bg-gray-50"
            >
              Ver rutina
            </Link>
          }
        />

        <section className="rounded-2xl bg-white p-8 shadow">
          {listaEjercicios.length === 0 ? (
            <p className="text-gray-600">
              No hay ejercicios disponibles en este momento.
            </p>
          ) : (
            <ListaEjerciciosFiltrada ejercicios={listaEjercicios} />
          )}
        </section>
      </div>
    </main>
  );
}