import Link from "next/link";
import { obtenerResumenInicio } from "@/lib/progreso/obtenerResumenInicio";
import { comprobarRutinaDesactualizada } from "@/lib/rutina/comprobarRutinaDesactualizada";
import { obtenerUsuarioActual } from "@/lib/auth/obtenerUsuarioActual";

export const dynamic = "force-dynamic";

export default async function PaginaInicio() {
  await obtenerUsuarioActual();

  const resumen = await obtenerResumenInicio();

  const perfil = resumen.perfil;
  const rutina = resumen.rutinaGuardada?.rutina ?? null;
  const ultimaRutinaGuardada = resumen.rutinaGuardada;
  const progreso = resumen.progreso;

  const rutinaDesactualizada = comprobarRutinaDesactualizada(
    perfil,
    ultimaRutinaGuardada?.rutina ?? null,
  );

  const tienePerfil = Boolean(perfil);
  const tieneRutina = Boolean(rutina);
  const sesionesRegistradas = progreso?.sesionesTotales ?? 0;

  const siguienteAccion = !tienePerfil
    ? {
        titulo: "Completar perfil",
        descripcion:
          "Antes de generar rutinas necesitas guardar tus datos, objetivo, nivel, disponibilidad y equipamiento.",
        href: "/onboarding",
        textoBoton: "Completar onboarding",
      }
    : !tieneRutina
      ? {
          titulo: "Generar rutina",
          descripcion:
            "Ya tienes perfil guardado. El siguiente paso es generar una rutina adaptada a tus datos.",
          href: "/rutina?modo=nueva",
          textoBoton: "Generar rutina",
        }
      : rutinaDesactualizada
        ? {
            titulo: "Actualizar rutina",
            descripcion:
              "Tu perfil ha cambiado desde que se guardó la rutina. Conviene regenerarla para mantener la coherencia.",
            href: "/rutina?modo=nueva",
            textoBoton: "Regenerar rutina",
          }
        : sesionesRegistradas === 0
          ? {
              titulo: "Registrar primera sesión",
              descripcion:
                "Ya tienes perfil y rutina. Empieza un entrenamiento para generar datos de progreso.",
              href: "/entrenamiento",
              textoBoton: "Ir a entrenamiento",
            }
          : {
              titulo: "Continuar entrenando",
              descripcion:
                "La aplicación ya tiene datos suficientes para seguir adaptando tu progreso.",
              href: "/entrenamiento",
              textoBoton: "Continuar entrenamiento",
            };

  return (
    <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
      <div className="mx-auto max-w-6xl space-y-6">
        <section className="rounded-2xl bg-white p-8 shadow">
          <div className="grid gap-6 lg:grid-cols-[1.4fr_0.9fr] lg:items-start">
            <div>
              <p className="mb-2 text-sm font-medium text-gray-500">
                Panel principal
              </p>
              <h1 className="mb-3 text-3xl font-bold">Inicio</h1>
              <p className="max-w-2xl text-gray-600">
                Desde aquí puedes revisar tu perfil actual, ver la última rutina
                guardada, acceder al entrenamiento y consultar tu progreso.
              </p>

              <div className="mt-6 flex flex-wrap gap-3">
                <Link
                  href={siguienteAccion.href}
                  className="rounded-lg bg-black px-5 py-3 text-white"
                >
                  {siguienteAccion.textoBoton}
                </Link>

                {tieneRutina && (
                  <Link
                    href="/rutina"
                    className="rounded-lg border px-5 py-3 hover:bg-gray-50"
                  >
                    Ver rutina
                  </Link>
                )}

                {tienePerfil && (
                  <Link
                    href="/perfil"
                    className="rounded-lg border px-5 py-3 hover:bg-gray-50"
                  >
                    Ver perfil
                  </Link>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-1">
              <article className="rounded-xl border p-4">
                <p className="text-sm text-gray-500">Objetivo actual</p>
                <p className="mt-2 text-lg font-semibold">
                  {perfil?.objetivo ?? "No indicado"}
                </p>
              </article>

              <article className="rounded-xl border p-4">
                <p className="text-sm text-gray-500">Nivel</p>
                <p className="mt-2 text-lg font-semibold">
                  {perfil?.nivel ?? "No indicado"}
                </p>
              </article>

              <article className="rounded-xl border p-4">
                <p className="text-sm text-gray-500">Días por semana</p>
                <p className="mt-2 text-lg font-semibold">
                  {perfil?.dias_por_semana ?? "-"}
                </p>
              </article>

              <article className="rounded-xl border p-4">
                <p className="text-sm text-gray-500">Rutina guardada</p>
                <p className="mt-2 text-lg font-semibold">
                  {rutina ? "Disponible" : "No guardada"}
                </p>
              </article>
            </div>
          </div>
        </section>

        {rutinaDesactualizada && (
          <section className="rounded-2xl border border-yellow-300 bg-yellow-50 p-6 shadow">
            <h2 className="text-xl font-semibold text-yellow-800">
              Rutina posiblemente desactualizada
            </h2>

            <p className="mt-2 text-sm text-yellow-700">
              El perfil ha cambiado después de guardar la última rutina.
              Conviene revisar o regenerar la rutina para que vuelva a coincidir
              con tu objetivo, nivel, equipamiento y molestias.
            </p>

            <div className="mt-4 flex flex-wrap gap-3">
              <Link
                href="/perfil"
                className="rounded-lg border border-yellow-700 px-4 py-2 text-yellow-800 hover:bg-yellow-100"
              >
                Revisar perfil
              </Link>

              <Link
                href="/rutina?modo=nueva"
                className="rounded-lg bg-black px-4 py-2 text-white"
              >
                Regenerar rutina
              </Link>
            </div>
          </section>
        )}

        <section className="rounded-2xl bg-white p-8 shadow">
          <div className="mb-6">
            <p className="mb-2 text-sm font-medium text-gray-500">
              Estado de la aplicación
            </p>
            <h2 className="text-2xl font-semibold">Estado actual</h2>
            <p className="mt-1 text-sm text-gray-600">
              Resumen rápido de preparación del usuario, disponibilidad de
              rutina y datos de entrenamiento registrados.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <article
              className={`rounded-xl border p-5 ${
                tienePerfil ? "bg-green-50 border-green-200" : "bg-white"
              }`}
            >
              <p className="text-sm text-gray-500">Perfil</p>
              <p className="mt-2 text-lg font-semibold">
                {tienePerfil ? "Configurado" : "Pendiente"}
              </p>
              <p className="mt-2 text-sm text-gray-600">
                {tienePerfil
                  ? "El usuario ya tiene objetivo, nivel y preferencias guardadas."
                  : "Falta completar el onboarding para poder personalizar la rutina."}
              </p>
            </article>

            <article
              className={`rounded-xl border p-5 ${
                tieneRutina && !rutinaDesactualizada
                  ? "bg-green-50 border-green-200"
                  : rutinaDesactualizada
                    ? "bg-yellow-50 border-yellow-300"
                    : "bg-white"
              }`}
            >
              <p className="text-sm text-gray-500">Rutina</p>
              <p className="mt-2 text-lg font-semibold">
                {!tieneRutina
                  ? "No generada"
                  : rutinaDesactualizada
                    ? "Desactualizada"
                    : "Disponible"}
              </p>
              <p className="mt-2 text-sm text-gray-600">
                {!tieneRutina
                  ? "Aún no hay una rutina guardada para entrenar."
                  : rutinaDesactualizada
                    ? "La rutina puede no coincidir con el perfil actual."
                    : "La rutina está disponible para entrenamiento."}
              </p>
            </article>

            <article
              className={`rounded-xl border p-5 ${
                sesionesRegistradas > 0
                  ? "bg-green-50 border-green-200"
                  : "bg-white"
              }`}
            >
              <p className="text-sm text-gray-500">Progreso</p>
              <p className="mt-2 text-lg font-semibold">
                {sesionesRegistradas > 0 ? "Con datos" : "Sin sesiones"}
              </p>
              <p className="mt-2 text-sm text-gray-600">
                {sesionesRegistradas > 0
                  ? `Hay ${sesionesRegistradas} sesiones registradas para analizar el progreso.`
                  : "Todavía no hay sesiones suficientes para calcular evolución real."}
              </p>
            </article>
          </div>

          <div className="mt-6 rounded-xl border bg-gray-50 p-5">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-sm text-gray-500">
                  Siguiente paso recomendado
                </p>
                <h3 className="mt-1 text-xl font-semibold">
                  {siguienteAccion.titulo}
                </h3>
                <p className="mt-2 text-sm text-gray-600">
                  {siguienteAccion.descripcion}
                </p>
              </div>

              <Link
                href={siguienteAccion.href}
                className="rounded-lg bg-black px-5 py-3 text-center text-white"
              >
                {siguienteAccion.textoBoton}
              </Link>
            </div>
          </div>
        </section>

        <section className="grid grid-cols-2 gap-4 xl:grid-cols-4">
          <div className="rounded-2xl bg-white p-6 shadow">
            <p className="text-sm text-gray-500">Sesiones completadas</p>
            <p className="mt-2 text-3xl font-bold">
              {progreso?.sesionesTotales ?? 0}
            </p>
          </div>

          <div className="rounded-2xl bg-white p-6 shadow">
            <p className="text-sm text-gray-500">Ejercicios completados</p>
            <p className="mt-2 text-3xl font-bold">
              {progreso?.ejerciciosTotales ?? 0}
            </p>
          </div>

          <div className="rounded-2xl bg-white p-6 shadow">
            <p className="text-sm text-gray-500">Series reales</p>
            <p className="mt-2 text-3xl font-bold">
              {progreso?.seriesTotales ?? 0}
            </p>
          </div>

          <div className="rounded-2xl bg-white p-6 shadow">
            <p className="text-sm text-gray-500">Suma de pesos registrados</p>
            <p className="mt-2 text-3xl font-bold">
              {progreso?.pesoTotalRegistrado ?? 0}
            </p>
          </div>
        </section>

        <section className="grid grid-cols-1 gap-6 xl:grid-cols-2">
          <div className="rounded-2xl bg-white p-8 shadow">
            <div className="mb-6 flex items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl font-semibold">Perfil actual</h2>
                <p className="mt-1 text-sm text-gray-600">
                  Resumen de la configuración activa del usuario.
                </p>
              </div>

              <Link
                href="/perfil"
                className="rounded-lg border px-4 py-2 hover:bg-gray-50"
              >
                Ver perfil
              </Link>
            </div>

            {!perfil ? (
              <p className="text-gray-600">Todavía no hay perfil guardado.</p>
            ) : (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <article className="rounded-xl border p-4">
                  <p className="text-sm text-gray-500">Nombre</p>
                  <p className="mt-1 font-medium">
                    {perfil.nombre || "Sin nombre"}
                  </p>
                </article>

                <article className="rounded-xl border p-4">
                  <p className="text-sm text-gray-500">Objetivo</p>
                  <p className="mt-1 font-medium">{perfil.objetivo}</p>
                </article>

                <article className="rounded-xl border p-4">
                  <p className="text-sm text-gray-500">Nivel</p>
                  <p className="mt-1 font-medium">{perfil.nivel}</p>
                </article>

                <article className="rounded-xl border p-4">
                  <p className="text-sm text-gray-500">Días por semana</p>
                  <p className="mt-1 font-medium">{perfil.dias_por_semana}</p>
                </article>

                <article className="rounded-xl border p-4 sm:col-span-2">
                  <p className="text-sm text-gray-500">Equipo disponible</p>
                  <p className="mt-1 font-medium">
                    {perfil.equipo_disponible
                      ? perfil.equipo_disponible.split(",").join(", ")
                      : "No indicado"}
                  </p>
                </article>
              </div>
            )}
          </div>

          <div className="rounded-2xl bg-white p-8 shadow">
            <div className="mb-6 flex items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl font-semibold">
                  Última rutina guardada
                </h2>
                <p className="mt-1 text-sm text-gray-600">
                  Última rutina disponible para entrenar o editar.
                </p>
              </div>

              <Link
                href="/rutina"
                className="rounded-lg border px-4 py-2 hover:bg-gray-50"
              >
                Ver rutina
              </Link>
            </div>

            {!rutina ? (
              <p className="text-gray-600">
                Todavía no hay ninguna rutina guardada.
              </p>
            ) : (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <article className="rounded-xl border p-4">
                  <p className="text-sm text-gray-500">Objetivo</p>
                  <p className="mt-1 font-medium">{rutina.objetivo}</p>
                </article>

                <article className="rounded-xl border p-4">
                  <p className="text-sm text-gray-500">Nivel</p>
                  <p className="mt-1 font-medium">{rutina.nivel}</p>
                </article>

                <article className="rounded-xl border p-4">
                  <p className="text-sm text-gray-500">Días por semana</p>
                  <p className="mt-1 font-medium">{rutina.dias_por_semana}</p>
                </article>

                <article className="rounded-xl border p-4">
                  <p className="text-sm text-gray-500">Índice de rotación</p>
                  <p className="mt-1 font-medium">
                    {rutina.indice_rotacion ?? 0}
                  </p>
                </article>
              </div>
            )}

            <div className="mt-6 flex flex-wrap gap-3">
              <Link
                href="/rutina"
                className="rounded-lg border px-5 py-3 hover:bg-gray-50"
              >
                Ver rutina
              </Link>

              <Link
                href="/entrenamiento"
                className="rounded-lg bg-black px-5 py-3 text-white"
              >
                Ir a entrenamiento
              </Link>
            </div>
          </div>
        </section>

        <section className="rounded-2xl bg-white p-8 shadow">
          <div className="mb-6">
            <h2 className="text-2xl font-semibold">Accesos rápidos</h2>
            <p className="mt-1 text-sm text-gray-600">
              Navegación directa a las secciones principales de la aplicación.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
            <Link
              href="/onboarding"
              className="rounded-xl border p-6 transition hover:bg-gray-50"
            >
              <h3 className="text-lg font-semibold">Configurar perfil</h3>
              <p className="mt-2 text-sm text-gray-600">
                Editar perfil y preferencias
              </p>
            </Link>

            <Link
              href="/ejercicios"
              className="rounded-xl border p-6 transition hover:bg-gray-50"
            >
              <h3 className="text-lg font-semibold">Ejercicios</h3>
              <p className="mt-2 text-sm text-gray-600">
                Consultar la biblioteca disponible
              </p>
            </Link>

            <Link
              href="/entrenamiento"
              className="rounded-xl border p-6 transition hover:bg-gray-50"
            >
              <h3 className="text-lg font-semibold">Entrenamiento</h3>
              <p className="mt-2 text-sm text-gray-600">
                Seguir la sesión actual
              </p>
            </Link>

            <Link
              href="/progreso"
              className="rounded-xl border p-6 transition hover:bg-gray-50"
            >
              <h3 className="text-lg font-semibold">Progreso</h3>
              <p className="mt-2 text-sm text-gray-600">
                Consultar la actividad guardada
              </p>
            </Link>
          </div>
        </section>
      </div>
    </main>
  );
}
