"use client";

import Link from "next/link";
import { useState } from "react";
import { guardarPerfilOnboarding } from "@/app/onboarding/acciones";
import { useRouter } from "next/navigation";
import { opcionesEquipamiento } from "@/lib/shared/opcionesEquipamiento";
import CabeceraPagina from "@/componentes/cabeceraPagina";

export default function PaginaOnboarding() {
    const router = useRouter();

    const [nombre, setNombre] = useState("");
    const [objetivo, setObjetivo] = useState("");
    const [nivel, setNivel] = useState("");
    const [diasPorSemana, setDiasPorSemana] = useState(3);
    const [duracionSesion, setDuracionSesion] = useState(60);
    const [equiposSeleccionados, setEquiposSeleccionados] = useState<string[]>([]);
    const [molestias, setMolestias] = useState("");
    const [guardando, setGuardando] = useState(false);
    const [mensaje, setMensaje] = useState("");

    function cambiarEquipo(equipo: string) {
        setEquiposSeleccionados((equiposActuales) => {
            if (equiposActuales.includes(equipo)) {
                return equiposActuales.filter((item) => item !== equipo);
            }

            return [...equiposActuales, equipo];
        });
    }

    async function guardarPerfil(evento: React.FormEvent<HTMLFormElement>) {
        evento.preventDefault();

        if (equiposSeleccionados.length === 0) {
            setMensaje("Selecciona al menos un equipo disponible.");
            return;
        }

        try {
            setGuardando(true);
            setMensaje("");

            const resultado = await guardarPerfilOnboarding({
                nombre: nombre.trim(),
                objetivo,
                nivel,
                dias_por_semana: diasPorSemana,
                duracion_sesion: duracionSesion,
                equipo_disponible: equiposSeleccionados.join(","),
                molestias: molestias.trim(),
            });

            if (!resultado.ok) {
                setMensaje(resultado.error ?? "No se ha podido guardar el perfil.");
                return;
            }

            setMensaje("Perfil guardado correctamente. Generando rutina adaptada...");
            router.push("/rutina?modo=nueva");
            router.refresh();
        } catch {
            setMensaje("Ha ocurrido un error al guardar el perfil.");
        } finally {
            setGuardando(false);
        }
    }

    return (
        <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
            <div className="mx-auto max-w-3xl space-y-6">
                <CabeceraPagina
                    titulo="Configuración inicial"
                    descripcion="Define tus datos de entrenamiento para generar una rutina adaptada a tu objetivo, nivel, disponibilidad y equipamiento."
                    acciones={
                        <Link
                            href="/perfil"
                            className="inline-flex min-w-[120px] items-center justify-center rounded-lg border px-5 py-3 text-center hover:bg-gray-50"
                        >
                            Ver perfil
                        </Link>
                    }
                />

                <section className="rounded-2xl bg-white p-8 shadow">
                    <form onSubmit={guardarPerfil} className="space-y-5">
                        <div>
                            <label className="mb-1 block font-medium">Nombre</label>
                            <input
                                type="text"
                                value={nombre}
                                onChange={(e) => setNombre(e.target.value)}
                                className="w-full rounded-lg border p-3"
                            />
                        </div>

                        <div>
                            <label className="mb-1 block font-medium">Objetivo</label>
                            <select
                                value={objetivo}
                                onChange={(e) => setObjetivo(e.target.value)}
                                className="w-full rounded-lg border p-3"
                                required
                            >
                                <option value="">Selecciona una opción</option>
                                <option value="hipertrofia">Hipertrofia</option>
                                <option value="fuerza">Fuerza</option>
                                <option value="mantenimiento">Mantenimiento</option>
                                <option value="recomposicion">Recomposición</option>
                            </select>
                        </div>

                        <div>
                            <label className="mb-1 block font-medium">Nivel</label>
                            <select
                                value={nivel}
                                onChange={(e) => setNivel(e.target.value)}
                                className="w-full rounded-lg border p-3"
                                required
                            >
                                <option value="">Selecciona una opción</option>
                                <option value="principiante">Principiante</option>
                                <option value="intermedio">Intermedio</option>
                                <option value="avanzado">Avanzado</option>
                            </select>
                        </div>

                        <div>
                            <label className="mb-1 block font-medium">Días por semana (1 a 7)</label>
                            <input
                                type="number"
                                min="1"
                                max="7"
                                value={diasPorSemana}
                                onChange={(e) => setDiasPorSemana(Number(e.target.value))}
                                className="w-full rounded-lg border p-3"
                                required
                            />
                        </div>

                        <div>
                            <label className="mb-1 block font-medium">
                                Duración por sesión (minutos)
                            </label>
                            <input
                                type="number"
                                min="15"
                                max="180"
                                value={duracionSesion}
                                onChange={(e) => setDuracionSesion(Number(e.target.value))}
                                className="w-full rounded-lg border p-3"
                                required
                            />
                        </div>

                        <div>
                            <label className="mb-2 block font-medium">Equipo disponible</label>

                            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                                {opcionesEquipamiento.map((equipo) => (
                                    <label
                                        key={equipo}
                                        className="flex items-center gap-2 rounded-lg border p-3"
                                    >
                                        <input
                                            type="checkbox"
                                            checked={equiposSeleccionados.includes(equipo)}
                                            onChange={() => cambiarEquipo(equipo)}
                                        />
                                        <span className="capitalize">{equipo}</span>
                                    </label>
                                ))}
                            </div>
                        </div>

                        <div>
                            <label className="mb-1 block font-medium">Molestias o lesiones</label>
                            <textarea
                                value={molestias}
                                onChange={(e) => setMolestias(e.target.value)}
                                className="w-full rounded-lg border p-3"
                                rows={4}
                                placeholder="hombro derecho, pierna izquierda..."
                            />
                        </div>

                        <div className="flex flex-wrap gap-3">
                            <button
                                type="submit"
                                disabled={guardando}
                                className="rounded-lg bg-black px-5 py-3 text-white disabled:opacity-50"
                            >
                                {guardando ? "Guardando..." : "Guardar perfil"}
                            </button>

                            <Link
                                href="/inicio"
                                className="rounded-lg border px-5 py-3 hover:bg-gray-50"
                            >
                                Ir a inicio
                            </Link>
                        </div>
                    </form>

                    {mensaje && (
                        <div className="mt-4 rounded-lg border bg-gray-50 p-3 text-sm text-gray-700">
                            {mensaje}
                        </div>
                    )}
                </section>
            </div>
        </main>
    );
}