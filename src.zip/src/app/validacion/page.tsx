import Link from "next/link";
import CabeceraPagina from "@/componentes/cabeceraPagina";
import ValidadorTecnica from "@/componentes/validadorTecnica";
import { obtenerUsuarioActual } from "@/lib/auth/obtenerUsuarioActual";

export const dynamic = "force-dynamic";

export default async function PaginaValidacionTecnica() {
  await obtenerUsuarioActual();

  return (
    <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
      <div className="mx-auto max-w-6xl space-y-6">
        <CabeceraPagina
          titulo="Validación técnica"
          descripcion="Sube un vídeo corto realizando un ejercicio y recibe una evaluación aproximada de la técnica mediante visión artificial."
          acciones={
            <Link
              href="/ejercicios"
              className="rounded-lg border px-5 py-3 hover:bg-gray-50"
            >
              Ver ejercicios
            </Link>
          }
        />

        <ValidadorTecnica />
      </div>
    </main>
  );
}