import Link from "next/link";
import { obtenerUltimoPerfil } from "@/lib/rutina/obtenerUltimaRutina";
import type { Perfil } from "@/tipos/perfil";
import FormularioPerfil from "@/componentes/formularioPerfil";
import CabeceraPagina from "@/componentes/cabeceraPagina";
import { obtenerUsuarioActual } from "@/lib/auth/obtenerUsuarioActual";

export const dynamic = "force-dynamic";

export default async function PaginaPerfil() {
  await obtenerUsuarioActual();

  const perfil = (await obtenerUltimoPerfil()) as Perfil | null;

  if (!perfil) {
    return (
      <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
        <div className="mx-auto max-w-3xl space-y-6">
          <CabeceraPagina
            titulo="Perfil"
            descripcion="Consulta y edita la configuración actual de tu cuenta."
            acciones={
              <Link
                href="/onboarding"
                className="rounded-lg bg-black px-5 py-3 text-white"
              >
                Crear perfil
              </Link>
            }
          />

          <section className="rounded-2xl bg-white p-8 shadow">
            <p className="text-gray-600">
              Todavía no hay ningún perfil guardado para este usuario.
            </p>
          </section>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-gray-50 px-4 py-8 md:px-6">
      <div className="mx-auto max-w-3xl space-y-6">
        <CabeceraPagina
          titulo="Perfil"
          descripcion="Revisa y actualiza tus datos, nivel, objetivo, equipamiento y molestias."
          acciones={
            <Link
              href="/rutina"
              className="rounded-lg border px-5 py-3 hover:bg-gray-50"
            >
              Revisar rutina
            </Link>
          }
        />

        <section className="rounded-2xl bg-white p-8 shadow">
          <FormularioPerfil perfil={perfil} />
        </section>
      </div>
    </main>
  );
}